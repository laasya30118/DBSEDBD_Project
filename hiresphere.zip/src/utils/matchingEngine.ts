import { Job, UserProfile, CandidateEvaluation, ParsedResume } from '../types';

/**
 * Normalizes strings for robust fuzzy skill and domain comparison
 */
function normalizeSkill(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Calculates candidate-job compatibility score and checks if candidate is "worthy for this job"
 */
export function evaluateCandidateForJob(
  candidate: UserProfile | ParsedResume,
  job: Job
): CandidateEvaluation {
  // Extract candidate skills
  let candidateSkills: string[] = [];
  let candidateExpYears = 0;
  let candidateEducation = '';

  if ('skills' in candidate && Array.isArray(candidate.skills)) {
    // UserProfile
    candidateSkills = (candidate as UserProfile).skills || [];
    candidateExpYears = (candidate as UserProfile).experienceYears || 0;
    candidateEducation = (candidate as UserProfile).education?.[0]?.degree || '';
  } else if ('skills' in candidate && typeof candidate.skills === 'object') {
    // ParsedResume
    const pResume = candidate as ParsedResume;
    candidateSkills = [
      ...(pResume.skills.technical || []),
      ...(pResume.skills.frameworksAndTools || []),
      ...(pResume.skills.softSkills || [])
    ];
    candidateExpYears = (pResume.experience || []).length * 1.5;
    candidateEducation = pResume.education?.[0]?.degree || '';
  }

  const normalizedCandidateSkills = candidateSkills.map(normalizeSkill);
  const matchedSkills: string[] = [];
  const missingSkills: string[] = [];

  job.skills.forEach((jobSkill) => {
    const norm = normalizeSkill(jobSkill);
    const hasMatch = normalizedCandidateSkills.some((candSkill) => {
      return (
        candSkill === norm ||
        candSkill.includes(norm) ||
        norm.includes(candSkill)
      );
    });

    if (hasMatch) {
      matchedSkills.push(jobSkill);
    } else {
      missingSkills.push(jobSkill);
    }
  });

  // Calculate percentage based on skills (65% weight), experience (25% weight), and education/context (10% weight)
  const skillRatio = job.skills.length > 0 ? matchedSkills.length / job.skills.length : 1;
  const expRatio = Math.min(1, Math.max(0.3, (candidateExpYears + 0.5) / Math.max(1, job.minExperienceYears)));
  const eduBonus = candidateEducation.toLowerCase().includes('tech') || 
                   candidateEducation.toLowerCase().includes('science') || 
                   candidateEducation.toLowerCase().includes('engineering') ? 1.0 : 0.8;

  let rawScore = Math.round(
    skillRatio * 65 +
    expRatio * 25 +
    eduBonus * 10
  );

  if (rawScore > 98) rawScore = 98;
  if (rawScore < 25) rawScore = 25;

  const reasons: string[] = [];
  if (skillRatio >= 0.7) {
    reasons.push(`Possesses ${matchedSkills.length} of ${job.skills.length} required key skills.`);
  } else {
    reasons.push(`Missing critical job skills: ${missingSkills.slice(0, 3).join(', ')}.`);
  }

  const experienceMatch = candidateExpYears >= job.minExperienceYears;
  if (experienceMatch) {
    reasons.push(`Meets experience threshold (${candidateExpYears} yrs vs ${job.minExperienceYears} yrs required).`);
  } else {
    reasons.push(`Experience (${candidateExpYears} yrs) is below requested requirement (${job.experienceRequired}).`);
  }

  let verdict: 'Strong Fit' | 'Worthy Candidate' | 'Moderate Fit' | 'High Gap' = 'Moderate Fit';
  let isWorthy = false;

  if (rawScore >= 80) {
    verdict = 'Strong Fit';
    isWorthy = true;
  } else if (rawScore >= 65) {
    verdict = 'Worthy Candidate';
    isWorthy = true;
  } else if (rawScore >= 50) {
    verdict = 'Moderate Fit';
    isWorthy = false;
  } else {
    verdict = 'High Gap';
    isWorthy = false;
  }

  return {
    isWorthy,
    score: rawScore,
    verdict,
    matchedSkills,
    missingSkills,
    experienceMatch,
    reasons
  };
}

/**
 * Re-ranks jobs according to user skills and interests
 */
export function getRecommendedJobs(jobs: Job[], user: UserProfile): Array<Job & { matchScore: number }> {
  return jobs
    .map((job) => {
      const evaluation = evaluateCandidateForJob(user, job);
      return {
        ...job,
        matchScore: evaluation.score
      };
    })
    .sort((a, b) => b.matchScore - a.matchScore);
}
