import React, { useState, useMemo } from 'react';
import { 
  Upload, 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  Download, 
  Printer, 
  Edit3, 
  Save, 
  Copy, 
  RefreshCw, 
  AlertCircle, 
  ArrowRight,
  Code2,
  FileCheck,
  Zap,
  ShieldCheck,
  AlertTriangle,
  FileSpreadsheet,
  Check,
  ExternalLink
} from 'lucide-react';
import { ParsedResume, UserProfile, ResumeAuditItem } from '../types';
import { 
  parseResumeRawText, 
  generateExactOrderFormattedText, 
  extractTextFromAnyFile, 
  auditResumeContent, 
  autoEnhanceResumeForATS 
} from '../utils/resumeParser';
import { SAMPLE_RESUMES } from '../data/sampleResumes';

interface ResumeParserProps {
  currentUser?: UserProfile | null;
  activeResume?: ParsedResume;
  onUpdateResume: (resume: ParsedResume) => void;
  onSyncProfile: (resume: ParsedResume) => void;
  onOpenInBuilder?: () => void;
  onNavigateToJobs?: () => void;
}

export const ResumeParser: React.FC<ResumeParserProps> = ({
  currentUser,
  activeResume,
  onUpdateResume,
  onSyncProfile,
  onOpenInBuilder,
  onNavigateToJobs
}) => {
  const [parsedData, setParsedData] = useState<ParsedResume>(activeResume || SAMPLE_RESUMES.mohana);
  const [isParsing, setIsParsing] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [rawTextInput, setRawTextInput] = useState('');
  const [showRawPaste, setShowRawPaste] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [fileTypeDetected, setFileTypeDetected] = useState<string | null>(null);
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [syncedNotification, setSyncedNotification] = useState(false);
  const [activeResumeSuccess, setActiveResumeSuccess] = useState(false);

  // Resume Error & ATS Audit
  const audit = useMemo(() => {
    const raw = `${parsedData.fullName}\n${parsedData.summary}\n${parsedData.skills.technical.join(', ')}\n${parsedData.experience.map(e => e.title + ' ' + e.highlights.join(' ')).join('\n')}`;
    return auditResumeContent(raw, parsedData);
  }, [parsedData]);

  // Handle File Upload (Drag & Drop or Selection)
  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  const processUploadedFile = async (file: File) => {
    setIsParsing(true);
    setUploadedFileName(file.name);

    try {
      // Universal extractor supporting PDF, DOCX, TXT, JSON, MD
      const result = await extractTextFromAnyFile(file);
      setFileTypeDetected(result.fileType);

      setTimeout(() => {
        const extracted = parseResumeRawText(result.text);
        setParsedData(extracted);
        onUpdateResume(extracted);
        setIsParsing(false);
        setActiveResumeSuccess(true);
        setTimeout(() => setActiveResumeSuccess(false), 4000);
      }, 600);
    } catch (err) {
      console.error('Error processing resume file', err);
      // Fallback
      setTimeout(() => {
        const fallback = parseResumeRawText(file.name);
        setParsedData(fallback);
        onUpdateResume(fallback);
        setIsParsing(false);
      }, 500);
    }
  };

  // Quick Load Sample Resumes
  const loadSample = (key: keyof typeof SAMPLE_RESUMES) => {
    setIsParsing(true);
    setUploadedFileName(null);
    setFileTypeDetected('Verified Sample');
    setTimeout(() => {
      const sample = SAMPLE_RESUMES[key];
      setParsedData(sample);
      onUpdateResume(sample);
      setIsParsing(false);
      setActiveResumeSuccess(true);
      setTimeout(() => setActiveResumeSuccess(false), 3000);
    }, 400);
  };

  // Parse Raw Text input
  const handleParsePastedText = () => {
    if (!rawTextInput.trim()) return;
    setIsParsing(true);
    setUploadedFileName('Pasted Raw Text');
    setFileTypeDetected('Plain Text');
    setTimeout(() => {
      const extracted = parseResumeRawText(rawTextInput);
      setParsedData(extracted);
      onUpdateResume(extracted);
      setIsParsing(false);
      setShowRawPaste(false);
      setActiveResumeSuccess(true);
      setTimeout(() => setActiveResumeSuccess(false), 4000);
    }, 500);
  };

  // Auto-Fix & Optimize for ATS
  const handleAutoFix = () => {
    const enhanced = autoEnhanceResumeForATS(parsedData);
    setParsedData(enhanced);
    onUpdateResume(enhanced);
    onSyncProfile(enhanced);
    setSyncedNotification(true);
    setTimeout(() => setSyncedNotification(false), 3000);
  };

  // Set as Active Application Resume & Apply to Jobs
  const handleSetActiveResume = () => {
    onUpdateResume(parsedData);
    onSyncProfile(parsedData);
    setActiveResumeSuccess(true);
    if (onNavigateToJobs) {
      setTimeout(() => onNavigateToJobs(), 800);
    }
  };

  // Download Exact Model Text
  const handleDownloadExactText = () => {
    const text = generateExactOrderFormattedText(parsedData);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${parsedData.fullName.replace(/\s+/g, '_')}_Exact_ATS_Resume.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Download Formatted PDF / Print
  const handlePrintResume = () => {
    window.print();
  };

  // Download JSON schema
  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(parsedData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${parsedData.fullName.replace(/\s+/g, '_')}_Parsed_Schema.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Copy text
  const handleCopyText = () => {
    const text = generateExactOrderFormattedText(parsedData);
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };
  const [copiedText, setCopiedText] = useState(false);

  return (
    <div id="resume-parser-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Universal File Parser, Error Detector & ATS Formatter</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            Resume Parsing, Quality Audit & Exact Model Download
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Upload your resume file (.PDF, .DOCX, .TXT, .JSON). The system scans for critical errors, computes your ATS compatibility score, and standardizes it into the exact model for immediate job applications.
          </p>
        </div>

        {/* Global CTA Actions */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            id="use-resume-for-jobs-btn"
            onClick={handleSetActiveResume}
            className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/30 flex items-center gap-2"
            title="Set this parsed resume as your verified document for job applications"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{activeResumeSuccess ? 'Resume Activated for Jobs!' : 'Use for Job Applications'}</span>
          </button>

          {onOpenInBuilder && (
            <button
              id="open-in-builder-btn"
              onClick={onOpenInBuilder}
              className="py-2.5 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
              title="Open and edit every field inside the interactive Resume Builder"
            >
              <Edit3 className="w-4 h-4" />
              <span>Open in Builder</span>
            </button>
          )}

          <button
            id="download-parsed-text-btn"
            onClick={handleDownloadExactText}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Download formatted text in exact corporate ATS sequence"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span>Download .TXT</span>
          </button>

          <button
            id="print-parsed-resume-btn"
            onClick={handlePrintResume}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Print or Save PDF"
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Active Resume Notification */}
      {activeResumeSuccess && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-3 rounded-xl shadow-xs flex items-center justify-between gap-3 text-xs animate-in fade-in no-print">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold">Resume Active & Verified!</span> All 25+ matching job vacancies will receive this parsed resume ({parsedData.fullName}, ATS {parsedData.atsScore}%).
            </div>
          </div>
          {onNavigateToJobs && (
            <button
              onClick={onNavigateToJobs}
              className="px-3 py-1 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 flex items-center gap-1 shrink-0"
            >
              <span>Explore Jobs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* File Upload Zone & Quick Samples */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 no-print">
        
        {/* Drag & Drop Upload Zone (7 cols on lg) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>Upload Resume Document</span>
            </h3>
            <span className="text-[11px] text-slate-500 font-mono">Supports PDF, DOCX, TXT, JSON</span>
          </div>

          <div
            onDragEnter={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={(e) => { e.preventDefault(); setDragActive(false); }}
            onDrop={handleFileDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
              dragActive 
                ? 'border-blue-500 bg-blue-50/60 scale-[1.01]' 
                : 'border-slate-300 hover:border-blue-400 bg-slate-50/60 hover:bg-blue-50/20'
            }`}
          >
            <input 
              type="file" 
              id="resume-file-input"
              accept=".pdf,.docx,.doc,.txt,.rtf,.json,.md"
              onChange={handleFileInput}
              className="hidden" 
            />
            <label htmlFor="resume-file-input" className="cursor-pointer block space-y-2">
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto shadow-xs">
                {isParsing ? (
                  <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
                ) : (
                  <FileSpreadsheet className="w-6 h-6" />
                )}
              </div>
              <div>
                <div className="text-xs font-bold text-slate-900">
                  {isParsing ? 'Parsing document & extracting entities...' : 'Click to select or drag and drop your resume file'}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  PDF, Microsoft Word (.docx), Plain Text (.txt), or JSON data
                </div>
              </div>

              {uploadedFileName && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                  <FileCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span>{uploadedFileName} ({fileTypeDetected || 'Processed'})</span>
                </div>
              )}
            </label>
          </div>

          {/* Alternative: Paste Raw Text */}
          <div className="pt-1">
            <button
              onClick={() => setShowRawPaste(!showRawPaste)}
              className="text-xs text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1"
            >
              <span>{showRawPaste ? 'Hide raw text input' : 'Or paste resume raw text directly'}</span>
            </button>

            {showRawPaste && (
              <div className="mt-2 space-y-2 animate-in fade-in duration-150">
                <textarea
                  rows={4}
                  value={rawTextInput}
                  onChange={(e) => setRawTextInput(e.target.value)}
                  placeholder="Paste raw resume text here..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-900 focus:outline-none focus:border-blue-500 font-mono text-[11px]"
                />
                <button
                  onClick={handleParsePastedText}
                  disabled={!rawTextInput.trim() || isParsing}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold transition-colors disabled:opacity-50"
                >
                  Parse Pasted Text
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Quick Sample Presets (5 cols on lg) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Instant Test Resumes</span>
            </h3>
            <span className="text-[11px] text-slate-500">1-Click Load</span>
          </div>
          <p className="text-xs text-slate-600">
            Quickly test the parsing engine, error detector, and ATS formatter with complete technical profiles:
          </p>

          <div className="space-y-2">
            <button
              onClick={() => loadSample('mohana')}
              className="w-full p-3 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600">
                  Mohana Asmitha — SDE & Full Stack
                </div>
                <div className="text-[11px] text-slate-500">
                  React, TypeScript, Python, PostgreSQL, Docker (ATS 95%)
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
            </button>

            <button
              onClick={() => loadSample('vikram')}
              className="w-full p-3 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600">
                  Vikram Malhotra — Cloud Architect Lead
                </div>
                <div className="text-[11px] text-slate-500">
                  Kubernetes, AWS, Go, Microservices (ATS 94%)
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
            </button>

            <button
              onClick={() => loadSample('aarav')}
              className="w-full p-3 rounded-xl border border-slate-200 hover:border-blue-400 hover:bg-blue-50/40 text-left transition-all flex items-center justify-between group"
            >
              <div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600">
                  Aarav Sharma — Senior Frontend Specialist
                </div>
                <div className="text-[11px] text-slate-500">
                  Next.js, Tailwind, Performance Optimization (ATS 92%)
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
            </button>
          </div>
        </div>

      </div>

      {/* RESUME ERROR & QUALITY AUDIT CARD */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
              audit.score >= 85 ? 'bg-emerald-100 text-emerald-800' :
              audit.score >= 65 ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'
            }`}>
              {audit.score}%
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                <span>Resume Error & Quality Audit (ATS Screening Diagnostic)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Identifies missing contact info, keyword density gaps, weak phrasing, and lack of metrics.
              </p>
            </div>
          </div>

          <button
            onClick={handleAutoFix}
            className="py-2 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-2 shadow-sm transition-all shrink-0"
            title="Automatically enhance experience bullets with metrics and powerful action verbs"
          >
            <Zap className="w-4 h-4 text-amber-300" />
            <span>Auto-Fix & Optimize for ATS (+14%)</span>
          </button>
        </div>

        {/* Issues & Strengths Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          
          {/* Critical Issues */}
          {audit.criticalIssues.map((issue) => (
            <div key={issue.id} className="p-3.5 rounded-xl border border-red-200 bg-red-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-red-700 font-bold">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{issue.title}</span>
              </div>
              <p className="text-red-800 text-[11px] leading-relaxed">{issue.message}</p>
              <div className="text-[11px] font-semibold text-red-900 pt-1">
                Tip: {issue.recommendation}
              </div>
            </div>
          ))}

          {/* Warnings */}
          {audit.warnings.map((warn) => (
            <div key={warn.id} className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-amber-800 font-bold">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{warn.title}</span>
              </div>
              <p className="text-amber-900 text-[11px] leading-relaxed">{warn.message}</p>
              <div className="text-[11px] font-semibold text-amber-950 pt-1">
                Tip: {warn.recommendation}
              </div>
            </div>
          ))}

          {/* Strengths */}
          {audit.strengths.slice(0, 3).map((str) => (
            <div key={str.id} className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-800 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{str.title}</span>
              </div>
              <p className="text-emerald-900 text-[11px] leading-relaxed">{str.message}</p>
              <div className="text-[10px] text-emerald-700">Verified for ATS Parsers</div>
            </div>
          ))}

        </div>
      </div>

      {/* EXACT MODEL RESUME PREVIEW & DOWNLOAD SECTION */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        
        {/* Section Header */}
        <div className="bg-slate-50 p-4 sm:p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-900">
                Exact ATS Model Layout (Corporate 7-Section Sequence)
              </h2>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded-full uppercase">
                Standard Order
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Machine-readable plain text structure guaranteed to pass Greenhouse, Lever, and Workday ATS parsers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyText}
              className="py-1.5 px-3 rounded-lg bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Copy className="w-3.5 h-3.5 text-slate-500" />
              <span>{copiedText ? 'Copied!' : 'Copy Formatted Text'}</span>
            </button>

            <button
              onClick={handleDownloadExactText}
              className="py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .TXT</span>
            </button>

            <button
              onClick={handleDownloadJson}
              className="py-1.5 px-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download JSON</span>
            </button>
          </div>
        </div>

        {/* Exact Model Presentation Card */}
        <div className="p-6 sm:p-8 space-y-6 text-xs text-slate-800 leading-relaxed font-sans">
          
          {/* 1. Header Contact */}
          <div className="border-b-2 border-slate-900 pb-4">
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {parsedData.fullName}
            </h1>
            <div className="text-sm font-semibold text-blue-600 mt-0.5">
              {parsedData.experience[0]?.title || 'Software Development Engineer'}
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-slate-600 text-xs mt-2">
              <span>Email: {parsedData.email}</span>
              <span>•</span>
              <span>Phone: {parsedData.phone}</span>
              <span>•</span>
              <span>Location: {parsedData.location}</span>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-blue-700 text-xs mt-1">
              {parsedData.links.linkedin && <span>LinkedIn: {parsedData.links.linkedin}</span>}
              {parsedData.links.github && <span>GitHub: {parsedData.links.github}</span>}
              {parsedData.links.portfolio && <span>Portfolio: {parsedData.links.portfolio}</span>}
            </div>
          </div>

          {/* 2. Professional Summary */}
          <div>
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
              1. Professional Summary
            </div>
            <p className="text-slate-700 leading-relaxed">
              {parsedData.summary}
            </p>
          </div>

          {/* 3. Skills */}
          <div>
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
              2. Core Technical & Professional Skills
            </div>
            <div className="space-y-1.5">
              <div>
                <span className="font-semibold text-slate-800">Programming Languages & Technologies: </span>
                <span className="text-slate-700">{parsedData.skills.technical.join(', ')}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-800">Frameworks, Cloud & Databases: </span>
                <span className="text-slate-700">{parsedData.skills.frameworksAndTools.join(', ')}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-800">Soft Skills & Methodology: </span>
                <span className="text-slate-700">{parsedData.skills.softSkills.join(', ')}</span>
              </div>
            </div>
          </div>

          {/* 4. Experience */}
          <div>
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
              3. Professional Experience & Highlights
            </div>
            <div className="space-y-4">
              {parsedData.experience.map((exp, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{exp.title} — {exp.company}</span>
                    <span className="text-slate-500 font-mono text-[11px]">{exp.startDate} – {exp.endDate}</span>
                  </div>
                  <ul className="pl-4 list-disc space-y-1 text-slate-700 marker:text-slate-400">
                    {exp.highlights.map((h, hIdx) => (
                      <li key={hIdx}>{h}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* 5. Education */}
          <div>
            <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
              4. Education & Academic Background
            </div>
            <div className="space-y-2">
              {parsedData.education.map((edu, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-slate-900">{edu.degree}</span>
                    <span className="text-slate-600"> — {edu.institution}</span>
                    {edu.gpa && <span className="text-slate-500"> (GPA: {edu.gpa})</span>}
                  </div>
                  <span className="text-slate-500 font-mono text-[11px]">{edu.year}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 6. Key Projects */}
          {parsedData.projects && parsedData.projects.length > 0 && (
            <div>
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
                5. Key Projects & Architecture
              </div>
              <div className="space-y-3">
                {parsedData.projects.map((proj, idx) => (
                  <div key={idx} className="space-y-0.5">
                    <div className="font-bold text-slate-900 flex items-center gap-2">
                      <span>• {proj.name}</span>
                      <span className="font-mono text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                        [{proj.techStack.join(', ')}]
                      </span>
                    </div>
                    <p className="text-slate-700 pl-3">{proj.description}</p>
                    {proj.link && (
                      <div className="pl-3 text-[11px] text-blue-600 font-mono">
                        URL: {proj.link}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. Certifications */}
          {parsedData.certifications && parsedData.certifications.length > 0 && (
            <div>
              <div className="text-xs font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200 mb-2">
                6. Certifications & Accreditations
              </div>
              <ul className="pl-4 list-disc space-y-1 text-slate-700 marker:text-blue-500">
                {parsedData.certifications.map((cert, idx) => (
                  <li key={idx}>{cert}</li>
                ))}
              </ul>
            </div>
          )}

        </div>

        {/* Footer Bar inside Preview */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 no-print">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">Verified ATS Readability Score:</span>
            <span className="font-bold text-emerald-600">{parsedData.atsScore}/100</span>
            <span className="text-slate-400">•</span>
            <span className="text-[11px] text-slate-500">Parsed at: {parsedData.parsedAt}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSetActiveResume}
              className="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Check className="w-4 h-4" />
              <span>Use This Resume for Job Applications</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
