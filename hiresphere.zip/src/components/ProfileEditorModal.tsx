import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  User, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Link as LinkIcon, 
  CheckCircle2, 
  Sparkles, 
  Building, 
  Plus, 
  Trash2,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { INITIAL_CANDIDATE_PROFILE } from '../data/sampleResumes';

export interface ProfileEditorModalProps {
  isOpen: boolean;
  user?: UserProfile | null;
  isPostLogin?: boolean;
  onClose: () => void;
  onSave: (updatedUser: UserProfile, targetTab?: 'profile' | 'jobs' | 'recruiter') => void;
}

const COMMON_SKILLS_SUGGESTIONS = [
  'React', 'TypeScript', 'JavaScript', 'Node.js', 'Python', 'Java', 'PostgreSQL', 
  'MongoDB', 'AWS', 'Docker', 'Kubernetes', 'Git', 'Next.js', 'Tailwind CSS', 
  'GraphQL', 'System Design', 'CI/CD', 'Machine Learning'
];

export const ProfileEditorModal: React.FC<ProfileEditorModalProps> = ({
  isOpen,
  user,
  isPostLogin = false,
  onClose,
  onSave
}) => {
  const safeUser: UserProfile = user || INITIAL_CANDIDATE_PROFILE;

  // Active section tab for clean organization
  const [activeSection, setActiveSection] = useState<'basics' | 'role' | 'skills' | 'education' | 'experience' | 'links'>('basics');

  // Form states initialized with current user data
  const [fullName, setFullName] = useState(safeUser.fullName || '');
  const [role, setRole] = useState<UserRole>(safeUser.role || 'jobseeker');
  const [title, setTitle] = useState(safeUser.title || '');
  const [phone, setPhone] = useState(safeUser.phone || '');
  const [location, setLocation] = useState(safeUser.location || '');
  const [summary, setSummary] = useState(safeUser.summary || '');
  const [experienceYears, setExperienceYears] = useState(safeUser.experienceYears ?? 1);
  const [experienceLevel, setExperienceLevel] = useState(safeUser.experienceLevel || 'Entry Level');
  const [expectedSalary, setExpectedSalary] = useState(safeUser.expectedSalary || '₹18,00,000 / yr');

  // Recruiter specific fields
  const [companyName, setCompanyName] = useState(safeUser.companyName || 'Nexus Cloud Technologies');
  const [companyRole, setCompanyRole] = useState(safeUser.companyRole || 'Talent Acquisition & Hiring Lead');
  const [companyWebsite, setCompanyWebsite] = useState(safeUser.companyWebsite || 'https://nexuscloud.io');

  // Skills & Interests
  const [skillsList, setSkillsList] = useState<string[]>(safeUser.skills && safeUser.skills.length > 0 ? safeUser.skills : ['React', 'TypeScript', 'PostgreSQL']);
  const [newSkillInput, setNewSkillInput] = useState('');
  const [interestsInput, setInterestsInput] = useState(safeUser.interests ? safeUser.interests.join(', ') : 'Full Stack Development, Cloud Systems');

  // Education
  const [degree, setDegree] = useState(safeUser.education?.[0]?.degree || 'B.Tech in Computer Science');
  const [institution, setInstitution] = useState(safeUser.education?.[0]?.institution || 'Koneru Lakshmaiah Education Foundation');
  const [gradYear, setGradYear] = useState(safeUser.education?.[0]?.year || '2023 - 2027');
  const [gpa, setGpa] = useState(safeUser.education?.[0]?.gpa || '9.4 / 10');

  // Work History
  const [workRole, setWorkRole] = useState(safeUser.workHistory?.[0]?.role || safeUser.title || 'Software Engineering Intern');
  const [workCompany, setWorkCompany] = useState(safeUser.workHistory?.[0]?.company || 'Tech Innovations Lab');
  const [workDuration, setWorkDuration] = useState(safeUser.workHistory?.[0]?.duration || '2024 - Present');
  const [workDescription, setWorkDescription] = useState(
    safeUser.workHistory?.[0]?.description || 
    'Developed high-performance web components, automated CI/CD pipelines, and improved data querying speeds by 35%.'
  );

  // Certifications
  const [certificationsInput, setCertificationsInput] = useState(
    safeUser.certifications ? safeUser.certifications.join(', ') : 'AWS Certified Cloud Practitioner, Oracle Java Certified'
  );

  // Links
  const [linkedinUrl, setLinkedinUrl] = useState(safeUser.portfolioLinks?.linkedin || 'https://linkedin.com/in/mohana-asmitha');
  const [githubUrl, setGithubUrl] = useState(safeUser.portfolioLinks?.github || 'https://github.com/mohana-asmitha');
  const [websiteUrl, setWebsiteUrl] = useState(safeUser.portfolioLinks?.website || 'https://mohana-portfolio.dev');

  // Sync state whenever user or modal open state changes
  useEffect(() => {
    if (user) {
      setFullName(user.fullName || '');
      setRole(user.role || 'jobseeker');
      setTitle(user.title || '');
      setPhone(user.phone || '');
      setLocation(user.location || '');
      setSummary(user.summary || '');
      setExperienceYears(user.experienceYears ?? 1);
      setExperienceLevel(user.experienceLevel || 'Entry Level');
      setExpectedSalary(user.expectedSalary || '₹18,00,000 / yr');
      setCompanyName(user.companyName || 'Nexus Cloud Technologies');
      setCompanyRole(user.companyRole || 'Talent Acquisition & Hiring Lead');
      setCompanyWebsite(user.companyWebsite || 'https://nexuscloud.io');
      setSkillsList(user.skills && user.skills.length > 0 ? user.skills : ['React', 'TypeScript', 'PostgreSQL']);
      setInterestsInput(user.interests ? user.interests.join(', ') : 'Full Stack Development, Cloud Systems');
      setDegree(user.education?.[0]?.degree || 'B.Tech in Computer Science');
      setInstitution(user.education?.[0]?.institution || 'Koneru Lakshmaiah Education Foundation');
      setGradYear(user.education?.[0]?.year || '2023 - 2027');
      setGpa(user.education?.[0]?.gpa || '9.4 / 10');
      setWorkRole(user.workHistory?.[0]?.role || user.title || 'Software Engineering Intern');
      setWorkCompany(user.workHistory?.[0]?.company || 'Tech Innovations Lab');
      setWorkDuration(user.workHistory?.[0]?.duration || '2024 - Present');
      setWorkDescription(user.workHistory?.[0]?.description || 'Developed high-performance web components...');
      setCertificationsInput(user.certifications ? user.certifications.join(', ') : 'AWS Certified Cloud Practitioner, Oracle Java Certified');
      setLinkedinUrl(user.portfolioLinks?.linkedin || 'https://linkedin.com/in/mohana-asmitha');
      setGithubUrl(user.portfolioLinks?.github || 'https://github.com/mohana-asmitha');
      setWebsiteUrl(user.portfolioLinks?.website || 'https://mohana-portfolio.dev');
    }
  }, [user, isOpen]);

  // Handle skill adding
  const handleAddSkill = (skillToAdd: string) => {
    const trimmed = skillToAdd.trim();
    if (!trimmed) return;
    if (!skillsList.some(s => s.toLowerCase() === trimmed.toLowerCase())) {
      setSkillsList(prev => [...prev, trimmed]);
    }
    setNewSkillInput('');
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkillsList(prev => prev.filter(s => s !== skillToRemove));
  };

  const handleSubmit = (e: React.FormEvent, targetTab?: 'profile' | 'jobs' | 'recruiter') => {
    e.preventDefault();

    const parsedInterests = interestsInput.split(',').map(s => s.trim()).filter(Boolean);
    const parsedCerts = certificationsInput.split(',').map(s => s.trim()).filter(Boolean);

    const updatedUser: UserProfile = {
      ...safeUser,
      fullName: fullName.trim() || safeUser.fullName,
      role: role,
      title: title.trim() || (role === 'recruiter' ? 'Talent Acquisition Specialist' : 'Software Engineer'),
      phone: phone.trim() || safeUser.phone,
      location: location.trim() || safeUser.location,
      summary: summary.trim() || safeUser.summary,
      experienceYears: Number(experienceYears),
      experienceLevel: experienceLevel as any,
      expectedSalary: expectedSalary.trim(),
      companyName: role === 'recruiter' ? companyName.trim() : undefined,
      companyRole: role === 'recruiter' ? companyRole.trim() : undefined,
      companyWebsite: role === 'recruiter' ? companyWebsite.trim() : undefined,
      skills: skillsList.length > 0 ? skillsList : ['React', 'TypeScript'],
      interests: parsedInterests.length > 0 ? parsedInterests : ['Full Stack Development'],
      education: [
        {
          degree: degree.trim(),
          institution: institution.trim(),
          year: gradYear.trim(),
          gpa: gpa.trim()
        }
      ],
      workHistory: [
        {
          role: workRole.trim(),
          company: workCompany.trim(),
          duration: workDuration.trim(),
          description: workDescription.trim()
        }
      ],
      certifications: parsedCerts,
      portfolioLinks: {
        linkedin: linkedinUrl.trim() || undefined,
        github: githubUrl.trim() || undefined,
        website: websiteUrl.trim() || undefined
      }
    };

    onSave(updatedUser, targetTab);
  };

  if (!isOpen) return null;

  return (
    <div 
      id="profile-editor-overlay"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="profile-editor-modal"
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-500/25">
              {isPostLogin ? <Sparkles className="w-5 h-5" /> : <User className="w-5 h-5" />}
            </div>
            <div>
              <h2 id="profile-editor-title" className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
                <span>{isPostLogin ? 'Confirm & Edit Your Profile Details' : 'Edit Professional Profile'}</span>
                {isPostLogin && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/30 text-blue-300 border border-blue-400/30">
                    Post-Login Setup
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">
                {isPostLogin 
                  ? 'Welcome to HireSphere! Review your profile details below. Everything is stored in your Profile tab and can be edited anytime.'
                  : 'Update your career credentials, verified competencies, and personal details in your profile.'}
              </p>
            </div>
          </div>
          <button
            id="profile-editor-close-btn"
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex overflow-x-auto border-b border-slate-200 bg-slate-50 px-4 py-2 gap-1.5 scrollbar-none text-xs">
          <button
            type="button"
            onClick={() => setActiveSection('basics')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'basics' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Basics & Contact</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('role')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'role' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Role & Compensation</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('skills')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'skills' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Skills & Interests ({skillsList.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('education')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'education' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Education</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('experience')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'experience' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>Experience & Summary</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('links')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeSection === 'links' 
                ? 'bg-blue-600 text-white shadow-xs' 
                : 'text-slate-600 hover:bg-slate-200/70 hover:text-slate-900'
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5" />
            <span>Links & Certs</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={(e) => handleSubmit(e, 'profile')} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 text-xs">
          
          {/* SECTION 1: BASICS & CONTACT */}
          {activeSection === 'basics' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                <span>These primary details appear at the top of your Profile, on resume exports, and in recruiter search results.</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
                  <input
                    id="profile-edit-fullname"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. M. Mohana Asmitha"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address</label>
                  <input
                    id="profile-edit-email"
                    type="email"
                    disabled
                    value={user.email}
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-500 cursor-not-allowed font-medium"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">Email is tied to your account login.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    id="profile-edit-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Location / City</label>
                  <input
                    id="profile-edit-location"
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Hyderabad, India"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Professional Title / Headline *</label>
                <input
                  id="profile-edit-title"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Full Stack Developer & Distributed Systems Engineer"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* SECTION 2: ROLE & COMPENSATION */}
          {activeSection === 'role' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">Portal Role Perspective</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setRole('jobseeker')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
                      role === 'jobseeker' 
                        ? 'border-blue-600 bg-blue-50/70 text-blue-900 ring-2 ring-blue-500/20' 
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <User className={`w-5 h-5 shrink-0 mt-0.5 ${role === 'jobseeker' ? 'text-blue-600' : 'text-slate-400'}`} />
                    <div>
                      <div className="font-bold text-xs">Job Seeker / Candidate</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">Explore openings, calculate match scores, submit applications, build resumes.</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRole('recruiter')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-all ${
                      role === 'recruiter' 
                        ? 'border-purple-600 bg-purple-50/70 text-purple-900 ring-2 ring-purple-500/20' 
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Building className={`w-5 h-5 shrink-0 mt-0.5 ${role === 'recruiter' ? 'text-purple-600' : 'text-slate-400'}`} />
                    <div>
                      <div className="font-bold text-xs">Talent Recruiter / Hiring Lead</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">Post job openings, review candidate resumes, shortlist and schedule interviews.</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Recruiter specific inputs */}
              {role === 'recruiter' && (
                <div className="p-4 bg-purple-50/60 border border-purple-200 rounded-xl space-y-3">
                  <div className="font-bold text-purple-900 text-xs flex items-center gap-1.5">
                    <Building className="w-4 h-4 text-purple-600" />
                    <span>Recruiter Organization Details</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Hiring Company Name</label>
                      <input
                        type="text"
                        value={companyName}
                        onChange={(e) => setCompanyName(e.target.value)}
                        placeholder="Nexus Cloud Technologies"
                        className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:border-purple-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Recruiter Role / Title</label>
                      <input
                        type="text"
                        value={companyRole}
                        onChange={(e) => setCompanyRole(e.target.value)}
                        placeholder="Head of Technical Talent"
                        className="w-full bg-white border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 focus:border-purple-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Total Experience (Years)</label>
                  <input
                    type="number"
                    min={0}
                    max={35}
                    value={experienceYears}
                    onChange={(e) => setExperienceYears(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Experience Level</label>
                  <select
                    value={experienceLevel}
                    onChange={(e) => setExperienceLevel(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  >
                    <option value="Entry Level">Entry Level (0-1 yrs)</option>
                    <option value="Mid Level">Mid Level (2-4 yrs)</option>
                    <option value="Senior">Senior (5-8 yrs)</option>
                    <option value="Lead">Lead / Architect (8+ yrs)</option>
                    <option value="Executive">Executive / Director</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Expected Salary / CTC</label>
                  <input
                    type="text"
                    value={expectedSalary}
                    onChange={(e) => setExpectedSalary(e.target.value)}
                    placeholder="e.g. ₹18,00,000 / yr"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: SKILLS & INTERESTS */}
          {activeSection === 'skills' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Active Competency Skills ({skillsList.length})
                </label>
                <p className="text-[11px] text-slate-500 mb-2">
                  Our matching engine computes job match scores by comparing these skills against employer vacancy requirements.
                </p>

                {/* Skill Chips */}
                <div className="flex flex-wrap gap-1.5 p-3 bg-slate-50 rounded-xl border border-slate-200 min-h-16">
                  {skillsList.map(skill => (
                    <span 
                      key={skill}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 text-xs font-semibold"
                    >
                      <span>{skill}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveSkill(skill)}
                        className="text-blue-500 hover:text-red-600 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </span>
                  ))}
                  {skillsList.length === 0 && (
                    <span className="text-slate-400 text-xs italic">No skills added yet. Add some below!</span>
                  )}
                </div>

                {/* Add new custom skill */}
                <div className="flex gap-2 mt-2">
                  <input
                    type="text"
                    value={newSkillInput}
                    onChange={(e) => setNewSkillInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSkill(newSkillInput);
                      }
                    }}
                    placeholder="Type a skill (e.g. Kubernetes, Redis, Docker)..."
                    className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddSkill(newSkillInput)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </div>

                {/* Quick suggestions */}
                <div className="mt-3">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">Quick Suggestions:</span>
                  <div className="flex flex-wrap gap-1">
                    {COMMON_SKILLS_SUGGESTIONS.filter(s => !skillsList.includes(s)).slice(0, 10).map(s => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => handleAddSkill(s)}
                        className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-blue-100 text-slate-700 hover:text-blue-700 text-[11px] font-medium border border-slate-200 transition-colors"
                      >
                        + {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Career Interests & Target Domains (comma-separated)
                </label>
                <input
                  type="text"
                  value={interestsInput}
                  onChange={(e) => setInterestsInput(e.target.value)}
                  placeholder="e.g. Full Stack Development, Cloud Engineering, Artificial Intelligence"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* SECTION 4: EDUCATION */}
          {activeSection === 'education' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Degree / Specialization *</label>
                  <input
                    type="text"
                    required
                    value={degree}
                    onChange={(e) => setDegree(e.target.value)}
                    placeholder="e.g. B.Tech in Computer Science and Engineering"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">College / University *</label>
                  <input
                    type="text"
                    required
                    value={institution}
                    onChange={(e) => setInstitution(e.target.value)}
                    placeholder="e.g. Koneru Lakshmaiah Education Foundation"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Graduation Period</label>
                  <input
                    type="text"
                    value={gradYear}
                    onChange={(e) => setGradYear(e.target.value)}
                    placeholder="e.g. 2023 - 2027"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">GPA / Score</label>
                  <input
                    type="text"
                    value={gpa}
                    onChange={(e) => setGpa(e.target.value)}
                    placeholder="e.g. 9.4 / 10"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* SECTION 5: EXPERIENCE & SUMMARY */}
          {activeSection === 'experience' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Professional Summary / Bio</label>
                <textarea
                  rows={3}
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  placeholder="Provide a concise summary of your technical background, accomplishments, and career focus..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none resize-none leading-relaxed"
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="font-bold text-slate-800 text-xs flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-blue-600" />
                  <span>Primary / Current Work Experience</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Job Role / Designation</label>
                    <input
                      type="text"
                      value={workRole}
                      onChange={(e) => setWorkRole(e.target.value)}
                      placeholder="Software Engineering Intern"
                      className="w-full bg-white border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Company / Organization</label>
                    <input
                      type="text"
                      value={workCompany}
                      onChange={(e) => setWorkCompany(e.target.value)}
                      placeholder="Tech Innovations Lab"
                      className="w-full bg-white border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Duration</label>
                  <input
                    type="text"
                    value={workDuration}
                    onChange={(e) => setWorkDuration(e.target.value)}
                    placeholder="2024 - Present"
                    className="w-full bg-white border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Key Responsibilities & Highlights</label>
                  <textarea
                    rows={2}
                    value={workDescription}
                    onChange={(e) => setWorkDescription(e.target.value)}
                    placeholder="Contributed to scalable APIs, automated deployment scripts, and collaborated with frontend teams..."
                    className="w-full bg-white border border-slate-300 rounded-xl p-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* SECTION 6: LINKS & CERTS */}
          {activeSection === 'links' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">LinkedIn Profile URL</label>
                  <input
                    type="url"
                    value={linkedinUrl}
                    onChange={(e) => setLinkedinUrl(e.target.value)}
                    placeholder="https://linkedin.com/in/username"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">GitHub Profile URL</label>
                  <input
                    type="url"
                    value={githubUrl}
                    onChange={(e) => setGithubUrl(e.target.value)}
                    placeholder="https://github.com/username"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Personal Portfolio / Website</label>
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="https://myportfolio.dev"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Certifications (comma-separated)</label>
                <input
                  type="text"
                  value={certificationsInput}
                  onChange={(e) => setCertificationsInput(e.target.value)}
                  placeholder="AWS Cloud Practitioner, React Certified Developer"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-xs text-slate-900 font-medium focus:border-blue-500 focus:bg-white focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* Modal Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-500">
                All changes sync automatically to your <strong className="text-slate-800">Profile</strong> tab.
              </span>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                id="profile-editor-cancel-btn"
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors"
              >
                {isPostLogin ? 'Skip for Now' : 'Cancel'}
              </button>

              {isPostLogin ? (
                <>
                  <button
                    id="save-profile-and-view-btn"
                    type="button"
                    onClick={(e) => handleSubmit(e, 'profile')}
                    className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/25 flex items-center justify-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save & View Profile</span>
                  </button>

                  <button
                    id="save-profile-and-jobs-btn"
                    type="button"
                    onClick={(e) => handleSubmit(e, role === 'recruiter' ? 'recruiter' : 'jobs')}
                    className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/25 flex items-center justify-center gap-1.5"
                  >
                    <span>Save & Explore Portal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </>
              ) : (
                <button
                  id="save-profile-changes-btn"
                  type="submit"
                  className="flex-1 sm:flex-none py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-600/25 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Profile Details</span>
                </button>
              )}
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};
