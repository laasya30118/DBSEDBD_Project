import React, { useState, useMemo } from 'react';
import { 
  Search, 
  MapPin, 
  Briefcase, 
  DollarSign, 
  Sparkles, 
  Filter, 
  CheckCircle2, 
  Clock, 
  Building2, 
  SlidersHorizontal,
  ArrowRight,
  Zap,
  FileText
} from 'lucide-react';
import { Job, UserProfile, JobApplication, ParsedResume } from '../types';
import { evaluateCandidateForJob } from '../utils/matchingEngine';
import { ApplyModal } from './ApplyModal';
import { INITIAL_CANDIDATE_PROFILE } from '../data/sampleResumes';

interface JobSearchProps {
  jobs: Job[];
  currentUser?: UserProfile | null;
  activeResume?: ParsedResume;
  onApply: (application: JobApplication) => void;
  appliedJobIds?: Set<string> | string[];
}

export const JobSearch: React.FC<JobSearchProps> = ({
  jobs,
  currentUser,
  activeResume,
  onApply,
  appliedJobIds = new Set<string>()
}) => {
  const safeUser: UserProfile = currentUser || INITIAL_CANDIDATE_PROFILE;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [sortByMatch, setSortByMatch] = useState<boolean>(true);
  const [selectedJobForModal, setSelectedJobForModal] = useState<Job | null>(null);
  const [selectedJobForDetails, setSelectedJobForDetails] = useState<Job | null>(null);

  // Normalize appliedJobIds into a Set to safely support arrays, Sets, and undefined
  const appliedSet = useMemo(() => {
    if (appliedJobIds instanceof Set) return appliedJobIds;
    if (Array.isArray(appliedJobIds)) return new Set<string>(appliedJobIds);
    return new Set<string>();
  }, [appliedJobIds]);

  // Extract unique categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    jobs.forEach(j => set.add(j.category));
    return ['All', ...Array.from(set)];
  }, [jobs]);

  // Compute match score and filter jobs
  const evaluatedJobs = useMemo(() => {
    const list = jobs.map(job => {
      const evaluation = evaluateCandidateForJob(safeUser, job);
      return {
        ...job,
        evaluation
      };
    });

    return list.filter(job => {
      const matchesSearch = 
        job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        job.skills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCat = selectedCategory === 'All' || job.category === selectedCategory;
      const matchesType = selectedType === 'All' || job.type === selectedType;

      return matchesSearch && matchesCat && matchesType;
    });
  }, [jobs, safeUser, searchQuery, selectedCategory, selectedType]);

  const sortedJobs = useMemo(() => {
    if (sortByMatch) {
      return [...evaluatedJobs].sort((a, b) => b.evaluation.score - a.evaluation.score);
    }
    return evaluatedJobs;
  }, [evaluatedJobs, sortByMatch]);

  return (
    <div id="job-search-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Search & Hero Banner */}
      <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-800 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-semibold mb-3 border border-blue-400/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Context & Skills Matching Engine Active</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Discover Suitable Career Opportunities
          </h1>
          <p className="text-sm text-slate-300 mt-2 leading-relaxed">
            Curated vacancies matched against your verified skills in <span className="text-blue-400 font-semibold">{(safeUser.skills || []).slice(0, 4).join(', ') || 'Software Engineering'}</span>. Our compatibility algorithm ranks each opening for your professional profile.
          </p>

          {/* Search bar input */}
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
              <input
                id="job-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search jobs by title, skills (e.g. React, PostgreSQL), company..."
                className="w-full bg-slate-800/95 border border-slate-700 rounded-xl pl-12 pr-4 py-3 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex gap-2">
              <select
                id="filter-type-select"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="bg-slate-800 border border-slate-700 text-white text-xs font-medium rounded-xl px-4 py-3 focus:outline-none focus:border-blue-500"
              >
                <option value="All">All Work Modes</option>
                <option value="Full-Time">Full-Time</option>
                <option value="Remote">Remote Only</option>
                <option value="Hybrid">Hybrid</option>
              </select>

              <button
                id="toggle-match-sort-btn"
                onClick={() => setSortByMatch(!sortByMatch)}
                className={`px-4 py-3 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors ${
                  sortByMatch
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
                title="Sort by skills compatibility score"
              >
                <Zap className="w-4 h-4" />
                <span className="hidden sm:inline">Sort: {sortByMatch ? 'Highest Match' : 'Default'}</span>
              </button>
            </div>
          </div>

          {/* Quick Skill Tags Filter */}
          <div className="mt-4 flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-slate-400 mr-1">Suggested Skill Filters:</span>
            {['React', 'PostgreSQL', 'Python', 'Docker', 'AWS', 'FastAPI', 'Kubernetes'].map(skill => (
              <button
                key={skill}
                onClick={() => setSearchQuery(searchQuery === skill ? '' : skill)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                  searchQuery.toLowerCase().includes(skill.toLowerCase())
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60'
                }`}
              >
                {skill}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active Resume Status Card */}
      {activeResume && (
        <div className="bg-gradient-to-r from-blue-900/40 via-slate-900/60 to-indigo-950/40 border border-blue-500/30 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-400/30 flex items-center justify-center text-blue-400 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm">Active Resume Attached: {activeResume?.fullName || 'Candidate Resume'}</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                  {activeResume.atsScore}% ATS Verified
                </span>
              </div>
              <p className="text-slate-300 text-[11px] mt-0.5">
                Targeting: {activeResume.experience?.[0]?.title || activeResume.role || 'Full Stack Engineer'} • Skills: {activeResume.skills?.technical?.slice(0, 5).join(', ') || 'Various'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Attached to All Applications</span>
            </span>
          </div>
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat} {cat === 'All' ? `(${jobs.length})` : ''}
          </button>
        ))}
      </div>

      {/* Job Counter Bar */}
      <div className="flex items-center justify-between text-xs text-slate-500 px-1">
        <div>
          Showing <span className="font-bold text-slate-800">{sortedJobs.length}</span> verified vacancies matching your criteria
        </div>
        <div>
          Target candidate: <span className="font-semibold text-slate-700">{safeUser.fullName || 'Candidate'} ({safeUser.title || 'Job Seeker'})</span>
        </div>
      </div>

      {/* Jobs Grid (20-30 realistic jobs) */}
      {sortedJobs.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
          <p className="text-base font-semibold text-slate-700">No vacancies matching your search query.</p>
          <p className="text-xs text-slate-400 mt-1">Try resetting the category filter or clearing the skill search query.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedType('All');
            }}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-semibold hover:bg-blue-500"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div id="job-cards-container" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {sortedJobs.map(job => {
            const hasApplied = appliedSet.has(job.id);
            const evalData = job.evaluation;

            return (
              <div
                key={job.id}
                id={`job-card-${job.id}`}
                className="bg-white rounded-2xl border border-slate-200 hover:border-blue-400/80 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
              >
                {/* Card Top */}
                <div className="p-5">
                  
                  {/* Company & Badges */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center border border-slate-200 text-sm shrink-0">
                        {job.company.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-xs font-semibold text-slate-600">{job.company}</h4>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                          <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate max-w-[140px]">{job.location}</span>
                        </div>
                      </div>
                    </div>

                    {/* Compatibility Match Badge */}
                    <div 
                      className={`px-2.5 py-1 rounded-full text-xs font-bold shrink-0 flex items-center gap-1 border ${
                        evalData.score >= 80 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : evalData.score >= 65
                          ? 'bg-blue-50 text-blue-700 border-blue-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                      title={`Compatibility score: ${evalData.score}%. ${evalData.reasons.join(' ')}`}
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>{evalData.score}% Fit</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-slate-900 leading-snug group-hover:text-blue-600 transition-colors mb-2">
                    {job.title}
                  </h3>

                  {/* Description snippet */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
                    {job.description}
                  </p>

                  {/* Quick stats: Salary, Type, Exp */}
                  <div className="flex flex-wrap gap-2 text-[11px] font-medium text-slate-600 mb-4 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="flex items-center gap-1 text-slate-800 font-semibold">
                      <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                      {job.salary}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                      {job.experienceRequired}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="px-1.5 py-0.5 rounded bg-white text-slate-700 border border-slate-200">
                      {job.type}
                    </span>
                  </div>

                  {/* Required Skills & Candidate Match Indicators */}
                  <div>
                    <div className="text-[11px] font-semibold text-slate-500 mb-1.5 flex items-center justify-between">
                      <span>Key Skills ({evalData.matchedSkills.length}/{job.skills.length} matched):</span>
                      <span className="text-[10px] text-emerald-700 font-bold">{evalData.verdict}</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {job.skills.slice(0, 5).map(skill => {
                        const isMatch = evalData.matchedSkills.includes(skill);
                        return (
                          <span
                            key={skill}
                            className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                              isMatch
                                ? 'bg-emerald-100/70 text-emerald-800 border border-emerald-300 font-semibold flex items-center gap-0.5'
                                : 'bg-slate-100 text-slate-600 border border-slate-200'
                            }`}
                          >
                            {isMatch && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-700" />}
                            {skill}
                          </span>
                        );
                      })}
                      {job.skills.length > 5 && (
                        <span className="px-1.5 py-0.5 text-[10px] text-slate-400">
                          +{job.skills.length - 5} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="p-4 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    id={`view-details-${job.id}`}
                    onClick={() => setSelectedJobForDetails(job)}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900 py-2 px-2.5 rounded-lg hover:bg-slate-200/60 transition-colors"
                  >
                    View Details
                  </button>

                  {hasApplied ? (
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 px-3 py-2 bg-emerald-50 rounded-xl border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Applied
                    </span>
                  ) : (
                    <button
                      id={`apply-btn-${job.id}`}
                      onClick={() => setSelectedJobForModal(job)}
                      className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-colors shadow-sm flex items-center gap-1.5"
                    >
                      <span>Apply Now</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Apply Modal */}
      {selectedJobForModal && (
        <ApplyModal
          job={selectedJobForModal}
          currentUser={safeUser}
          activeResume={activeResume}
          onClose={() => setSelectedJobForModal(null)}
          onSubmit={(app) => {
            onApply(app);
          }}
        />
      )}

      {/* Job Details Modal Drawer */}
      {selectedJobForDetails && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-6 border-b border-slate-200 bg-slate-900 text-white flex items-start justify-between">
              <div>
                <span className="text-xs text-blue-400 font-semibold uppercase">{selectedJobForDetails.category}</span>
                <h2 className="text-xl font-bold text-white mt-1">{selectedJobForDetails.title}</h2>
                <div className="text-xs text-slate-300 mt-1 flex items-center gap-2">
                  <span className="font-semibold">{selectedJobForDetails.company}</span>
                  <span>•</span>
                  <span>{selectedJobForDetails.location}</span>
                  <span>•</span>
                  <span>{selectedJobForDetails.salary}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedJobForDetails(null)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs text-slate-700">
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-1">Role Description</h4>
                <p className="leading-relaxed">{selectedJobForDetails.description}</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">Key Responsibilities</h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-600">
                  {selectedJobForDetails.responsibilities.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">Candidate Requirements & Qualifications</h4>
                <ul className="list-disc list-inside space-y-1.5 text-slate-600">
                  {selectedJobForDetails.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">Required Skills</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedJobForDetails.skills.map(skill => (
                    <span key={skill} className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-md font-medium">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setSelectedJobForDetails(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close
              </button>

              {appliedSet.has(selectedJobForDetails.id) ? (
                <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" /> You have already applied for this opening
                </span>
              ) : (
                <button
                  onClick={() => {
                    const j = selectedJobForDetails;
                    setSelectedJobForDetails(null);
                    setSelectedJobForModal(j);
                  }}
                  className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow"
                >
                  Proceed to Apply Formalities
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
