import React from 'react';
import { 
  Briefcase, 
  Search, 
  FileText, 
  FileCode, 
  User, 
  Building2, 
  LogOut, 
  Sparkles,
  ChevronDown,
  Download
} from 'lucide-react';
import { UserProfile, ParsedResume } from '../types';

interface NavbarProps {
  activeTab: 'jobs' | 'recruiter' | 'resume-builder' | 'resume-parser' | 'builder' | 'parser' | 'profile';
  setActiveTab: (tab: any) => void;
  currentUser: UserProfile | null;
  onLogout: () => void;
  onToggleRole: () => void;
  appliedCount?: number;
  activeResume?: ParsedResume;
  onOpenAuth?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onLogout,
  onToggleRole,
  appliedCount = 0,
  activeResume,
  onOpenAuth
}) => {
  const [showResumeDropdown, setShowResumeDropdown] = React.useState(false);

  const isBuilderActive = activeTab === 'resume-builder' || (activeTab as string) === 'builder';
  const isParserActive = activeTab === 'resume-parser' || (activeTab as string) === 'parser';

  return (
    <header id="main-header" className="sticky top-0 z-40 bg-slate-900 text-white shadow-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Portal Title */}
          <div 
            id="brand-logo"
            onClick={() => setActiveTab('jobs')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/25 group-hover:bg-blue-500 transition-colors">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white">HireSphere</span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  Integrated
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Job Portal with Resume Parsing & Matching
              </p>
            </div>
          </div>

          {/* Center Navigation */}
          <nav id="navbar-links" className="hidden md:flex items-center gap-1">
            {/* 1. Job Search */}
            <button
              id="nav-jobs-btn"
              onClick={() => setActiveTab('jobs')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'jobs'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Search className="w-4 h-4" />
              <span>Explore Jobs</span>
            </button>

            {/* 2. Recruiter Hub */}
            <button
              id="nav-recruiter-btn"
              onClick={() => setActiveTab('recruiter')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'recruiter'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Recruiter Hub</span>
              {currentUser?.role === 'recruiter' && (
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              )}
            </button>

            {/* 3. Resume Building Direct Tab */}
            <button
              id="nav-builder-btn"
              onClick={() => setActiveTab('resume-builder')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isBuilderActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileCode className="w-4 h-4 text-blue-400" />
              <span>Resume Building</span>
            </button>

            {/* 4. Resume Parsing Direct Tab */}
            <button
              id="nav-parser-btn"
              onClick={() => setActiveTab('resume-parser')}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                isParserActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Resume Parsing</span>
            </button>

            {/* 5. Profile */}
            <button
              id="nav-profile-btn"
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'profile'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Profile</span>
              {appliedCount > 0 && (
                <span className="px-1.5 py-0.2 bg-blue-500 text-[10px] text-white font-bold rounded-full">
                  {appliedCount}
                </span>
              )}
            </button>
          </nav>

          {/* Right Action: User Status & Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Download Whole Project as ZIP */}
            <a
              id="download-project-zip-btn"
              href="/hiresphere-project.zip"
              download="hiresphere-project.zip"
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 transition-all shadow-xs"
              title="Download entire project code as a ZIP archive"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">Export ZIP</span>
            </a>

            {currentUser ? (
              <>
                {/* Quick Role Toggle */}
                <button
                  id="toggle-role-btn"
                  onClick={onToggleRole}
                  title="Switch perspective between Job Seeker and Recruiter"
                  className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-colors"
                >
                  <span>Perspective:</span>
                  <span className={`px-2 py-0.5 rounded ${currentUser?.role === 'recruiter' ? 'bg-purple-600/30 text-purple-300 border border-purple-500/30' : 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/30'}`}>
                    {currentUser?.role === 'recruiter' ? 'Recruiter' : 'Job Seeker'}
                  </span>
                </button>

                {/* Active Resume Status Chip if available */}
                {activeResume && (
                  <button
                    id="header-active-resume-chip"
                    onClick={() => setActiveTab('resume-parser')}
                    className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-medium hover:bg-emerald-500/20 transition-colors"
                    title="Active resume attached for all job applications. Click to view or edit."
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Resume: {(activeResume?.fullName || 'Candidate').split(' ')[0]}</span>
                    <span className="px-1 py-0.2 rounded bg-emerald-500/20 text-[9px] font-bold">
                      {activeResume.atsScore}% ATS
                    </span>
                  </button>
                )}

                {/* User Info Avatar */}
                <div 
                  id="user-profile-badge"
                  onClick={() => setActiveTab('profile')}
                  className="flex items-center gap-2.5 pl-2 pr-3 py-1 rounded-full bg-slate-800 border border-slate-700 cursor-pointer hover:border-slate-600 transition-colors"
                >
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-xs font-bold text-white shadow">
                    {currentUser?.fullName ? currentUser.fullName.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <div className="hidden sm:block text-left">
                    <div className="text-xs font-semibold text-white leading-tight truncate max-w-[120px]">
                      {currentUser?.fullName || currentUser?.email?.split('@')[0] || 'User'}
                    </div>
                    <div className="text-[10px] text-slate-400 leading-none">
                      {currentUser?.role === 'recruiter' ? 'Recruiter' : 'Candidate'}
                    </div>
                  </div>
                </div>

                {/* Logout button */}
                <button
                  id="logout-btn"
                  onClick={onLogout}
                  title="Log out of HireSphere"
                  className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <button
                id="login-modal-btn"
                onClick={onOpenAuth}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-md shadow-blue-500/20"
              >
                <User className="w-4 h-4" />
                <span>Sign In / Register</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Navigation bar below */}
      <div id="mobile-nav-bar" className="md:hidden flex items-center justify-around border-t border-slate-800 bg-slate-900/95 px-2 py-2 text-xs">
        <button
          onClick={() => setActiveTab('jobs')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded ${activeTab === 'jobs' ? 'text-blue-400 font-semibold' : 'text-slate-400'}`}
        >
          <Search className="w-4 h-4" />
          <span>Jobs</span>
        </button>
        <button
          onClick={() => setActiveTab('recruiter')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded ${activeTab === 'recruiter' ? 'text-blue-400 font-semibold' : 'text-slate-400'}`}
        >
          <Building2 className="w-4 h-4" />
          <span>Recruiter</span>
        </button>
        <button
          onClick={() => setActiveTab('resume-builder')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded ${isBuilderActive ? 'text-blue-400 font-semibold' : 'text-slate-400'}`}
        >
          <FileCode className="w-4 h-4" />
          <span>Builder</span>
        </button>
        <button
          onClick={() => setActiveTab('resume-parser')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded ${isParserActive ? 'text-blue-400 font-semibold' : 'text-slate-400'}`}
        >
          <FileText className="w-4 h-4" />
          <span>Parser</span>
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-1 py-1 px-2 rounded ${activeTab === 'profile' ? 'text-blue-400 font-semibold' : 'text-slate-400'}`}
        >
          <User className="w-4 h-4" />
          <span>Profile</span>
        </button>
      </div>
    </header>
  );
};
