import React, { useState } from 'react';
import { 
  Building2, 
  PlusCircle, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  FileText, 
  Eye, 
  Calendar, 
  Send, 
  AlertTriangle, 
  Sparkles, 
  Briefcase, 
  ChevronRight,
  ShieldCheck,
  Phone,
  Mail,
  ExternalLink
} from 'lucide-react';
import { Job, UserProfile, JobApplication, ParsedResume, CandidateEvaluation } from '../types';
import { evaluateCandidateForJob } from '../utils/matchingEngine';
import { INITIAL_RECRUITER_PROFILE } from '../data/sampleResumes';

interface RecruiterPortalProps {
  jobs: Job[];
  applications: JobApplication[];
  registeredCandidates: UserProfile[];
  currentRecruiter?: UserProfile | null;
  onPostJob: (newJob: Job) => void;
  onUpdateApplicationStatus: (appId: string, newStatus: JobApplication['status']) => void;
}

export const RecruiterPortal: React.FC<RecruiterPortalProps> = ({
  jobs,
  applications,
  registeredCandidates,
  currentRecruiter,
  onPostJob,
  onUpdateApplicationStatus
}) => {
  const safeRecruiter: UserProfile = currentRecruiter || INITIAL_RECRUITER_PROFILE;
  const [selectedJobId, setSelectedJobId] = useState<string>(jobs[0]?.id || '');
  const [viewingResumeCandidate, setViewingResumeCandidate] = useState<{
    profile?: UserProfile;
    resume?: ParsedResume;
    application?: JobApplication;
  } | null>(null);
  const [showPostJobModal, setShowPostJobModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'applications' | 'talent_pool'>('applications');
  const [candidateSearch, setCandidateSearch] = useState('');

  // Selected job
  const selectedJob = jobs.find(j => j.id === selectedJobId) || jobs[0];

  // Applications for this selected job
  const jobApplications = applications.filter(a => a.jobId === selectedJob?.id);

  // New job state form
  const [newTitle, setNewTitle] = useState('');
  const [newCompany, setNewCompany] = useState(currentRecruiter.companyName || 'Nexus Cloud Technologies');
  const [newLocation, setNewLocation] = useState('Hyderabad, India (Hybrid)');
  const [newType, setNewType] = useState<Job['type']>('Full-Time');
  const [newExp, setNewExp] = useState('2 - 5 years');
  const [newMinExp, setNewMinExp] = useState(2);
  const [newSalary, setNewSalary] = useState('₹18,00,000 - ₹28,00,000 / yr');
  const [newCategory, setNewCategory] = useState('Software Engineering');
  const [newSkills, setNewSkills] = useState('React, TypeScript, PostgreSQL, REST APIs');
  const [newDesc, setNewDesc] = useState('');

  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const parsedSkills = newSkills.split(',').map(s => s.trim()).filter(Boolean);
    const job: Job = {
      id: `job-${Date.now()}`,
      title: newTitle.trim(),
      company: newCompany.trim(),
      location: newLocation.trim(),
      type: newType,
      experienceRequired: newExp,
      minExperienceYears: Number(newMinExp),
      salary: newSalary.trim(),
      skills: parsedSkills.length > 0 ? parsedSkills : ['React', 'PostgreSQL', 'TypeScript'],
      category: newCategory,
      description: newDesc || `Seeking an ambitious ${newTitle} to architect scalable distributed services and high-efficiency product features.`,
      responsibilities: [
        'Design and deploy production-grade software features',
        'Participate in architecture reviews and database optimization',
        'Collaborate across cross-functional engineering pods'
      ],
      requirements: [
        `Demonstrated experience in ${parsedSkills.slice(0, 3).join(', ')}`,
        'Strong problem-solving capability and relational data modeling fundamentals'
      ],
      postedDate: 'Just now',
      recruiterId: safeRecruiter.id,
      recruiterEmail: safeRecruiter.email,
      applicantsCount: 0,
      isFeatured: true
    };

    onPostJob(job);
    setSelectedJobId(job.id);
    setShowPostJobModal(false);
    // Reset form
    setNewTitle('');
    setNewDesc('');
  };

  return (
    <div id="recruiter-portal-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Recruiter Header Bar */}
      <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-purple-400 font-semibold uppercase tracking-wider mb-1">
            <Building2 className="w-4 h-4" />
            <span>Recruiter Control Hub & Perspective</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Hiring Management & Candidate Evaluation
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Recruiter: <span className="text-white font-semibold">{safeRecruiter.fullName || 'Recruiting Partner'}</span> ({safeRecruiter.companyName || 'Recruiting Partner'}) • Review candidates & verify if they are worthy for your openings.
          </p>
        </div>

        <button
          id="post-new-job-btn"
          onClick={() => setShowPostJobModal(true)}
          className="py-3 px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-lg shadow-purple-600/30 flex items-center gap-2 shrink-0 self-start md:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Post New Job Vacancy</span>
        </button>
      </div>

      {/* Select Job Post Selector */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs">
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
          Select Active Job Posting to Evaluate Applicants:
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {jobs.slice(0, 6).map(job => {
            const isSelected = job.id === selectedJob?.id;
            const appCount = applications.filter(a => a.jobId === job.id).length;
            return (
              <div
                key={job.id}
                id={`recruiter-job-select-${job.id}`}
                onClick={() => setSelectedJobId(job.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  isSelected 
                    ? 'bg-purple-50/60 border-purple-500 shadow-sm ring-1 ring-purple-500/20' 
                    : 'bg-slate-50/50 border-slate-200 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{job.title}</h4>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 shrink-0">
                    {appCount} applied
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                  <span>{job.company}</span>
                  <span>•</span>
                  <span>{job.type}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Job Overview Banner */}
      {selectedJob && (
        <div id="active-job-perspective-card" className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700 bg-purple-50 px-2.5 py-1 rounded-md border border-purple-200">
                Active Job Post Under Evaluation
              </span>
              <h2 className="text-xl font-bold text-slate-900 mt-2">{selectedJob.title}</h2>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 mt-1">
                <span><strong>Company:</strong> {selectedJob.company}</span>
                <span>•</span>
                <span><strong>Location:</strong> {selectedJob.location}</span>
                <span>•</span>
                <span><strong>Experience Required:</strong> {selectedJob.experienceRequired}</span>
                <span>•</span>
                <span><strong>Offered Salary:</strong> {selectedJob.salary}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Required Stack:</span>
              <div className="flex flex-wrap gap-1">
                {selectedJob.skills.slice(0, 4).map(s => (
                  <span key={s} className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 text-[11px] font-medium">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sub-tab navigation: Applicants vs Registered Talent Pool */}
          <div className="flex items-center gap-4 mt-4 border-b border-slate-100 pb-3">
            <button
              onClick={() => setActiveTab('applications')}
              className={`text-xs font-bold pb-1 transition-colors flex items-center gap-1.5 ${
                activeTab === 'applications'
                  ? 'text-purple-700 border-b-2 border-purple-700'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Direct Applicants for this Post ({jobApplications.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('talent_pool')}
              className={`text-xs font-bold pb-1 transition-colors flex items-center gap-1.5 ${
                activeTab === 'talent_pool'
                  ? 'text-purple-700 border-b-2 border-purple-700'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Evaluate All Registered Talent ({registeredCandidates.length})</span>
            </button>
          </div>

          {/* TAB 1: Direct Applicants Reviewer */}
          {activeTab === 'applications' && (
            <div className="mt-5 space-y-4">
              {jobApplications.length === 0 ? (
                <div className="text-center py-10 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                  <p className="text-sm font-semibold text-slate-600">No applicants yet for this position.</p>
                  <p className="text-xs text-slate-400 mt-1">Switch to "Evaluate All Registered Talent" tab to screen candidates from the talent pool.</p>
                </div>
              ) : (
                jobApplications.map((app) => {
                  const evaluation = evaluateCandidateForJob(
                    app.resumeData || {
                      fullName: app.candidateName,
                      skills: app.matchedSkills,
                      experienceYears: 2,
                      title: app.candidateTitle
                    } as any,
                    selectedJob
                  );

                  return (
                    <div 
                      key={app.id} 
                      id={`applicant-card-${app.id}`}
                      className="p-5 rounded-2xl border border-slate-200 hover:border-purple-300 bg-slate-50/50 hover:bg-white transition-all space-y-3"
                    >
                      {/* Applicant Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 text-white font-bold text-sm flex items-center justify-center shrink-0 shadow">
                            {app.candidateName.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-bold text-slate-900">{app.candidateName}</h4>
                              <span className="text-[11px] text-slate-500">({app.candidateTitle})</span>
                            </div>
                            <div className="text-xs text-slate-500 flex items-center gap-3 mt-0.5">
                              <span className="flex items-center gap-1"><Mail className="w-3 h-3 text-slate-400" /> {app.candidateEmail}</span>
                              <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> {app.candidatePhone}</span>
                            </div>
                          </div>
                        </div>

                        {/* Automated Suitability & "Is Worthy" Verdict */}
                        <div className="flex items-center gap-2 shrink-0">
                          <div className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                            evaluation.isWorthy
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : 'bg-amber-50 text-amber-800 border-amber-300'
                          }`}>
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Compatibility: {evaluation.score}% • {evaluation.verdict}</span>
                          </div>
                          
                          <span className={`text-[11px] font-bold px-2.5 py-1 rounded-md ${
                            app.status === 'Shortlisted' ? 'bg-purple-100 text-purple-800' :
                            app.status === 'Interview Scheduled' ? 'bg-blue-100 text-blue-800' :
                            app.status === 'Offered' ? 'bg-emerald-100 text-emerald-800' :
                            app.status === 'Rejected' ? 'bg-rose-100 text-rose-800' :
                            'bg-slate-200 text-slate-700'
                          }`}>
                            {app.status}
                          </span>
                        </div>
                      </div>

                      {/* Recruiter Evaluation Perspective: Worthy or Not Details */}
                      <div className="p-3 bg-white rounded-xl border border-slate-200 text-xs space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-800">Recruiter Fit Analysis:</span>
                          <span className={`font-semibold ${evaluation.isWorthy ? 'text-emerald-600' : 'text-amber-600'}`}>
                            {evaluation.isWorthy ? '✓ Worthy for this Opening' : '⚠ Skill/Experience Gaps Present'}
                          </span>
                        </div>
                        
                        {/* Matched vs Missing Skills breakdown */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-1">
                          <div>
                            <span className="text-slate-500 font-medium">Matched Skills ({evaluation.matchedSkills.length}):</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {evaluation.matchedSkills.map(s => (
                                <span key={s} className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-medium flex items-center gap-1">
                                  <CheckCircle2 className="w-2.5 h-2.5" />
                                  {s}
                                </span>
                              ))}
                              {evaluation.matchedSkills.length === 0 && (
                                <span className="text-slate-400 italic text-[11px]">None matched</span>
                              )}
                            </div>
                          </div>

                          <div>
                            <span className="text-slate-500 font-medium">Missing Skills ({evaluation.missingSkills.length}):</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {evaluation.missingSkills.map(s => (
                                <span key={s} className="px-2 py-0.5 rounded bg-slate-100 text-slate-500 border border-slate-200 text-[10px]">
                                  {s}
                                </span>
                              ))}
                              {evaluation.missingSkills.length === 0 && (
                                <span className="text-emerald-600 font-semibold text-[11px]">All required skills satisfied!</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Candidate note */}
                        {app.coverNote && (
                          <div className="mt-2 pt-2 border-t border-slate-100 text-slate-600">
                            <span className="font-semibold text-slate-700">Candidate Note:</span>{' '}
                            <span className="italic">{app.coverNote}</span>
                          </div>
                        )}
                      </div>

                      {/* Recruiter Action Buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <button
                          id={`view-resume-${app.id}`}
                          onClick={() => setViewingResumeCandidate({
                            application: app,
                            resume: app.resumeData
                          })}
                          className="px-3.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 text-blue-600" />
                          <span>Inspect Parsed Resume Details</span>
                        </button>

                        <div className="flex items-center gap-2">
                          <button
                            id={`shortlist-btn-${app.id}`}
                            onClick={() => onUpdateApplicationStatus(app.id, 'Shortlisted')}
                            className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors"
                          >
                            Shortlist
                          </button>
                          <button
                            id={`interview-btn-${app.id}`}
                            onClick={() => onUpdateApplicationStatus(app.id, 'Interview Scheduled')}
                            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Schedule Interview</span>
                          </button>
                          <button
                            id={`offer-btn-${app.id}`}
                            onClick={() => onUpdateApplicationStatus(app.id, 'Offered')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors flex items-center gap-1"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Send Offer</span>
                          </button>
                          <button
                            id={`decline-btn-${app.id}`}
                            onClick={() => onUpdateApplicationStatus(app.id, 'Rejected')}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold transition-colors"
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 2: Registered Talent Pool Evaluator */}
          {activeTab === 'talent_pool' && (
            <div className="mt-5 space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span>Evaluate all candidates registered in HireSphere against <strong className="text-slate-800">{selectedJob.title}</strong>:</span>
                <input
                  type="text"
                  placeholder="Filter by candidate name or skill..."
                  value={candidateSearch}
                  onChange={(e) => setCandidateSearch(e.target.value)}
                  className="bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-800"
                />
              </div>

              {registeredCandidates
                .filter(c => 
                  c.fullName.toLowerCase().includes(candidateSearch.toLowerCase()) ||
                  c.skills.some(s => s.toLowerCase().includes(candidateSearch.toLowerCase()))
                )
                .map((cand) => {
                  const evaluation = evaluateCandidateForJob(cand, selectedJob);

                  return (
                    <div 
                      key={cand.id} 
                      className="p-4 rounded-xl border border-slate-200 bg-white hover:border-purple-300 transition-all space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-slate-900">{cand.fullName}</h4>
                            <span className="text-xs text-slate-500">• {cand.title}</span>
                          </div>
                          <div className="text-xs text-slate-500 mt-0.5">
                            {cand.location} • {cand.experienceYears} yrs experience ({cand.experienceLevel})
                          </div>
                        </div>

                        <div className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 self-start sm:self-auto ${
                          evaluation.isWorthy 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}>
                          <span>{evaluation.score}% Match • {evaluation.verdict}</span>
                        </div>
                      </div>

                      {/* Skills & Evaluator note */}
                      <div className="flex flex-wrap gap-1 text-xs">
                        {cand.skills.map(s => {
                          const isMatch = evaluation.matchedSkills.includes(s);
                          return (
                            <span key={s} className={`px-2 py-0.5 rounded text-[10px] ${
                              isMatch ? 'bg-emerald-100 text-emerald-800 font-semibold' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {s}
                            </span>
                          );
                        })}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                        <span className="text-slate-500">
                          {evaluation.isWorthy ? 'Candidate is highly worthy for this job vacancy.' : 'Candidate has noticeable stack differences.'}
                        </span>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setViewingResumeCandidate({ profile: cand })}
                            className="text-blue-600 hover:text-blue-700 font-semibold text-xs"
                          >
                            Inspect Profile
                          </button>
                          <button
                            onClick={() => alert(`Direct invitation and job formalities sent to ${cand.fullName} for ${selectedJob.title}!`)}
                            className="py-1 px-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors"
                          >
                            Invite to Apply
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}

        </div>
      )}

      {/* Post Job Modal */}
      {showPostJobModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-purple-400" />
                <h3 className="font-bold text-base">Post a New Job Vacancy</h3>
              </div>
              <button
                onClick={() => setShowPostJobModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateJob} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Job Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Senior Distributed Systems Engineer"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Hiring Company</label>
                  <input
                    type="text"
                    required
                    value={newCompany}
                    onChange={(e) => setNewCompany(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Location</label>
                  <input
                    type="text"
                    required
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Job Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  >
                    <option value="Full-Time">Full-Time</option>
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Contract">Contract</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  >
                    <option value="Software Engineering">Software Engineering</option>
                    <option value="Backend & Database">Backend & Database</option>
                    <option value="AI & Data Science">AI & Data Science</option>
                    <option value="Frontend Development">Frontend Development</option>
                    <option value="DevOps & Cloud">DevOps & Cloud</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Experience Requirement</label>
                  <input
                    type="text"
                    value={newExp}
                    onChange={(e) => setNewExp(e.target.value)}
                    placeholder="e.g. 2 - 5 years"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Offered Compensation</label>
                  <input
                    type="text"
                    value={newSalary}
                    onChange={(e) => setNewSalary(e.target.value)}
                    placeholder="e.g. ₹20,00,000 - ₹30,00,000 / yr"
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Required Skills (comma-separated)</label>
                <input
                  type="text"
                  required
                  value={newSkills}
                  onChange={(e) => setNewSkills(e.target.value)}
                  placeholder="React, TypeScript, PostgreSQL, Python, Docker"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Description & Requirements</label>
                <textarea
                  rows={3}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Describe key responsibilities and expectations..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-900 focus:outline-none focus:border-purple-500 resize-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowPostJobModal(false)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="py-2.5 px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold transition-colors shadow"
                >
                  Publish Vacancy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Candidate Full Resume / Profile Inspector Modal */}
      {viewingResumeCandidate && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div>
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">Candidate Resume & Credentials</span>
                <h3 className="text-lg font-bold text-white mt-0.5">
                  {viewingResumeCandidate.resume?.fullName || viewingResumeCandidate.profile?.fullName || 'Candidate Details'}
                </h3>
              </div>
              <button
                onClick={() => setViewingResumeCandidate(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-800 font-sans">
              
              {/* Summary */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1">Professional Summary</h4>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed text-slate-700">
                  {viewingResumeCandidate.resume?.summary || viewingResumeCandidate.profile?.summary || 'Experienced engineering professional.'}
                </p>
              </div>

              {/* Skills breakdown */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-2">Verified Skills & Tools</h4>
                <div className="flex flex-wrap gap-1.5">
                  {viewingResumeCandidate.resume ? (
                    <>
                      {viewingResumeCandidate.resume.skills.technical.map(s => (
                        <span key={s} className="px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-md font-medium">
                          {s}
                        </span>
                      ))}
                      {viewingResumeCandidate.resume.skills.frameworksAndTools.map(s => (
                        <span key={s} className="px-2.5 py-1 bg-slate-100 text-slate-700 border border-slate-200 rounded-md font-medium">
                          {s}
                        </span>
                      ))}
                    </>
                  ) : (
                    viewingResumeCandidate.profile?.skills.map(s => (
                      <span key={s} className="px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-md font-medium">
                        {s}
                      </span>
                    ))
                  )}
                </div>
              </div>

              {/* Experience Highlights */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-2">Work History & Contributions</h4>
                <div className="space-y-3">
                  {viewingResumeCandidate.resume?.experience?.map((exp, i) => (
                    <div key={i} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="flex items-center justify-between font-bold text-slate-900">
                        <span>{exp.title} — {exp.company}</span>
                        <span className="text-[10px] text-slate-500 font-normal">{exp.startDate} - {exp.endDate}</span>
                      </div>
                      <ul className="list-disc list-inside mt-2 space-y-1 text-slate-600">
                        {exp.highlights.map((h, idx) => (
                          <li key={idx}>{h}</li>
                        ))}
                      </ul>
                    </div>
                  )) || viewingResumeCandidate.profile?.workHistory.map((w, i) => (
                    <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="font-bold text-slate-900">{w.role} at {w.company}</div>
                      <div className="text-slate-500 text-[10px] mb-1">{w.duration}</div>
                      <p className="text-slate-600">{w.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Education */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px] mb-1">Education</h4>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  {viewingResumeCandidate.resume?.education?.[0] ? (
                    <div>
                      <div className="font-bold text-slate-900">{viewingResumeCandidate.resume.education[0].degree}</div>
                      <div className="text-slate-600">{viewingResumeCandidate.resume.education[0].institution} • {viewingResumeCandidate.resume.education[0].year}</div>
                    </div>
                  ) : viewingResumeCandidate.profile?.education?.[0] ? (
                    <div>
                      <div className="font-bold text-slate-900">{viewingResumeCandidate.profile.education[0].degree}</div>
                      <div className="text-slate-600">{viewingResumeCandidate.profile.education[0].institution} • {viewingResumeCandidate.profile.education[0].year}</div>
                    </div>
                  ) : (
                    <div>B.Tech in Computer Science & Engineering</div>
                  )}
                </div>
              </div>

            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setViewingResumeCandidate(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close Inspector
              </button>
              
              {viewingResumeCandidate.application && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onUpdateApplicationStatus(viewingResumeCandidate.application!.id, 'Shortlisted');
                      setViewingResumeCandidate(null);
                    }}
                    className="py-2 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs"
                  >
                    Shortlist Candidate
                  </button>
                  <button
                    onClick={() => {
                      onUpdateApplicationStatus(viewingResumeCandidate.application!.id, 'Interview Scheduled');
                      setViewingResumeCandidate(null);
                    }}
                    className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
                  >
                    Schedule Interview
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
