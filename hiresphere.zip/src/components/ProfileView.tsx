import React, { useState } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Briefcase, 
  GraduationCap, 
  Award, 
  Edit3, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  FileText, 
  ShieldCheck,
  Building2,
  Save,
  X,
  Globe
} from 'lucide-react';
import { UserProfile, JobApplication, ParsedResume } from '../types';
import { ProfileEditorModal } from './ProfileEditorModal';
import { INITIAL_CANDIDATE_PROFILE } from '../data/sampleResumes';

interface ProfileViewProps {
  user?: UserProfile | null;
  applications: JobApplication[];
  activeResume?: ParsedResume;
  onUpdateUser: (updated: UserProfile) => void;
  onSwitchToRecruiter: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  applications,
  activeResume,
  onUpdateUser,
  onSwitchToRecruiter
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const safeUser: UserProfile = user || INITIAL_CANDIDATE_PROFILE;

  // Filter applications made by this user
  const userApplications = applications.filter(a => a.candidateEmail === safeUser.email || a.candidateId === safeUser.id);

  return (
    <div id="profile-view-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Profile Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Cover gradient */}
        <div className="h-32 bg-gradient-to-r from-slate-900 via-blue-900 to-indigo-950 relative">
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              id="edit-profile-btn"
              onClick={() => setIsEditing(true)}
              className="py-1.5 px-3.5 rounded-xl bg-white/20 hover:bg-white/30 text-white text-xs font-semibold backdrop-blur-xs flex items-center gap-1.5 transition-colors border border-white/20"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Edit Professional Info</span>
            </button>
          </div>
        </div>

        {/* Info row */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12 mb-4">
            <div className="flex items-end gap-4">
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white text-3xl font-extrabold flex items-center justify-center shadow-xl border-4 border-white shrink-0">
                {safeUser.fullName ? safeUser.fullName.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="pb-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-bold text-slate-900">{safeUser.fullName || 'User Profile'}</h1>
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                    safeUser?.role === 'recruiter' 
                      ? 'bg-purple-100 text-purple-800' 
                      : 'bg-emerald-100 text-emerald-800'
                  }`}>
                    {safeUser?.role === 'recruiter' ? 'Verified Recruiter' : 'Job Seeker'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm font-semibold text-slate-600 mt-0.5">{safeUser.title}</p>
              </div>
            </div>

            {/* Expected Salary & Exp */}
            <div className="flex flex-wrap gap-2 text-xs">
              <div className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 font-medium">
                Experience: <span className="font-bold text-slate-900">{safeUser.experienceYears} Years</span> ({safeUser.experienceLevel})
              </div>
              {safeUser.expectedSalary && (
                <div className="px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 font-medium">
                  Expected CTC: <span className="font-bold text-slate-900">{safeUser.expectedSalary}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Contact & Links */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 pt-2 border-t border-slate-100">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              {safeUser.email}
            </span>
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              {safeUser.phone}
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {safeUser.location}
            </span>
            {safeUser.portfolioLinks?.linkedin && (
              <a 
                href={safeUser.portfolioLinks.linkedin} 
                target="_blank" 
                rel="noreferrer"
                className="text-blue-600 hover:underline flex items-center gap-1"
              >
                LinkedIn <ExternalLink className="w-3 h-3" />
              </a>
            )}
            {safeUser.portfolioLinks?.github && (
              <a 
                href={safeUser.portfolioLinks.github} 
                target="_blank" 
                rel="noreferrer"
                className="text-blue-600 hover:underline flex items-center gap-1"
              >
                GitHub <ExternalLink className="w-3 h-3" />
              </a>
            )}
            {safeUser.portfolioLinks?.website && (
              <a 
                href={safeUser.portfolioLinks.website} 
                target="_blank" 
                rel="noreferrer"
                className="text-blue-600 hover:underline flex items-center gap-1"
              >
                <Globe className="w-3.5 h-3.5" />
                Portfolio Website <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: Left Details + Right Applications Tracker */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Professional Details (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Summary / Bio */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Professional Career Summary
            </h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              {safeUser.summary}
            </p>
          </div>

          {/* Verified Skills Cloud */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3">
              Verified Technical Competencies & Skills ({safeUser.skills?.length || 0})
            </h3>
            <div className="flex flex-wrap gap-1.5">
              {(safeUser.skills || []).map(skill => (
                <span
                  key={skill}
                  className="px-3 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                  {skill}
                </span>
              ))}
            </div>
            {safeUser.interests && safeUser.interests.length > 0 && (
              <div className="mt-4 pt-3 border-t border-slate-100">
                <span className="text-[11px] font-semibold text-slate-500 block mb-1.5">Domains & Target Roles:</span>
                <div className="flex flex-wrap gap-1.5">
                  {safeUser.interests.map(interest => (
                    <span key={interest} className="px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[11px]">
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Work History */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-blue-600" />
              <span>Career Experience History</span>
            </h3>
            <div className="space-y-4">
              {(safeUser.workHistory || []).map((wh, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                  <div className="flex items-center justify-between font-bold text-slate-900">
                    <span>{wh.role}</span>
                    <span className="text-[11px] font-normal text-slate-500">{wh.duration}</span>
                  </div>
                  <div className="text-blue-700 font-semibold text-[11px] mt-0.5">{wh.company}</div>
                  <p className="text-slate-600 mt-1.5 leading-relaxed">{wh.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Certifications */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-600" />
                <span>Education & Academic Credentials</span>
              </h3>
              {(safeUser.education || []).map((edu, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                  <div className="font-bold text-slate-900">{edu.degree}</div>
                  <div className="text-slate-600">{edu.institution} • {edu.year}</div>
                  {edu.gpa && <div className="text-slate-500 text-[11px] mt-0.5">GPA: {edu.gpa}</div>}
                </div>
              ))}
            </div>

            {safeUser.certifications && safeUser.certifications.length > 0 && (
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>Certifications & Accreditations</span>
                </h4>
                <ul className="list-disc list-inside space-y-1 text-xs text-slate-700">
                  {safeUser.certifications.map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

        </div>

        {/* RIGHT COLUMN: Formalities & Applied Vacancies Tracker (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Active Resume Status Card */}
          <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400">
                Resume Intelligence Status
              </span>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-400/30">
                ATS Ready
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">
              {activeResume ? `${activeResume.fullName || 'Candidate'}'s Parsed Resume` : `${safeUser.fullName || 'User'} - Standard Profile Resume`}
            </h4>
            <div className="flex items-center gap-4 text-xs text-slate-300 mt-2">
              <span>ATS Score: <strong className="text-emerald-400">{activeResume?.atsScore || 94}%</strong></span>
              <span>•</span>
              <span>Updated: Recently</span>
            </div>
          </div>

          {/* Applications Formalities & Tracker */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Applied Job Formalities
                </h3>
                <p className="text-[11px] text-slate-500">Track sent applications & recruiter review status</p>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
                {userApplications.length} Applied
              </span>
            </div>

            {userApplications.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700">No applications submitted yet.</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Explore the job catalog to apply with match formalities.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {userApplications.map((app) => (
                  <div 
                    key={app.id} 
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-white transition-all space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-bold text-slate-900 leading-snug">{app.jobTitle}</h4>
                        <div className="text-slate-500 text-[11px]">{app.company}</div>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                        app.status === 'Shortlisted' ? 'bg-purple-100 text-purple-800' :
                        app.status === 'Interview Scheduled' ? 'bg-blue-100 text-blue-800' :
                        app.status === 'Offered' ? 'bg-emerald-100 text-emerald-800' :
                        app.status === 'Rejected' ? 'bg-rose-100 text-rose-800' :
                        'bg-slate-200 text-slate-700'
                      }`}>
                        {app.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                      <span>Match Compatibility: <strong className="text-emerald-600">{app.matchScore}%</strong></span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {app.appliedDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* Edit Profile Modal */}
      <ProfileEditorModal
        isOpen={isEditing}
        user={safeUser}
        isPostLogin={false}
        onClose={() => setIsEditing(false)}
        onSave={(updated) => {
          onUpdateUser(updated);
          setIsEditing(false);
        }}
      />

    </div>
  );
};
