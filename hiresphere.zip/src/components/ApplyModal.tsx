import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Upload, 
  Send, 
  Building2, 
  MapPin, 
  Clock, 
  DollarSign, 
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { Job, UserProfile, JobApplication, ParsedResume } from '../types';
import { evaluateCandidateForJob } from '../utils/matchingEngine';
import { INITIAL_CANDIDATE_PROFILE } from '../data/sampleResumes';

interface ApplyModalProps {
  job: Job;
  currentUser?: UserProfile | null;
  activeResume?: ParsedResume;
  onClose: () => void;
  onSubmit: (application: JobApplication) => void;
}

export const ApplyModal: React.FC<ApplyModalProps> = ({
  job,
  currentUser,
  activeResume,
  onClose,
  onSubmit
}) => {
  const safeUser: UserProfile = currentUser || INITIAL_CANDIDATE_PROFILE;
  const evaluation = evaluateCandidateForJob(safeUser, job);
  const [coverNote, setCoverNote] = useState(
    `Dear Hiring Team at ${job.company},\n\nI am excited to apply for the ${job.title} role. With my background in ${(safeUser.skills || []).slice(0, 3).join(', ')}, I believe I can deliver immediate value to your engineering initiatives.\n\nBest regards,\n${safeUser.fullName || 'Candidate'}`
  );
  const [noticePeriod, setNoticePeriod] = useState('Immediate (within 15 days)');
  const [expectedSalary, setExpectedSalary] = useState(safeUser.expectedSalary || job.salary.split('-')[0].trim());
  const [selectedResumeType, setSelectedResumeType] = useState<'profile' | 'custom'>('profile');
  const [uploadedResumeName, setUploadedResumeName] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedResumeName(file.name);
      setSelectedResumeType('custom');
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const application: JobApplication = {
        id: `app-${Date.now()}`,
        jobId: job.id,
        jobTitle: job.title,
        company: job.company,
        candidateId: safeUser.id,
        candidateName: safeUser.fullName || 'Candidate',
        candidateEmail: safeUser.email || '',
        candidatePhone: safeUser.phone || '',
        candidateTitle: safeUser.title || '',
        candidateLocation: safeUser.location || '',
        matchScore: evaluation.score,
        matchedSkills: evaluation.matchedSkills,
        missingSkills: evaluation.missingSkills,
        appliedDate: 'Just now',
        status: 'Applied',
        coverNote: coverNote,
        resumeData: activeResume
      };

      onSubmit(application);
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  return (
    <div id="apply-modal-overlay" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div 
        id="apply-modal-content" 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-400/30">
                Application Formalities
              </span>
              <span className="text-xs text-slate-400">{job.type}</span>
            </div>
            <h2 className="text-lg font-bold text-white mt-1 leading-snug">
              {job.title}
            </h2>
            <div className="flex items-center gap-3 text-xs text-slate-300 mt-0.5">
              <span className="flex items-center gap-1 font-medium"><Building2 className="w-3.5 h-3.5 text-blue-400" /> {job.company}</span>
              <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-slate-400" /> {job.location}</span>
            </div>
          </div>
          <button
            id="apply-modal-close-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        {isSubmitted ? (
          <div id="apply-success-state" className="p-8 text-center my-auto space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900">Application Submitted!</h3>
            <p className="text-sm text-slate-600 max-w-md mx-auto">
              Your resume and professional application have been formally sent to the recruiter at <span className="font-semibold text-slate-900">{job.company}</span> with an automated compatibility match score of <span className="font-bold text-emerald-600">{evaluation.score}%</span>.
            </p>
            <div className="pt-2">
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors shadow-md"
              >
                Return to Job Search
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleFormSubmit} className="overflow-y-auto p-6 space-y-5">
            
            {/* Intelligent Compatibility Match Card */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Automated Compatibility Match
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`text-base font-extrabold ${
                    evaluation.score >= 80 ? 'text-emerald-600' : evaluation.score >= 60 ? 'text-blue-600' : 'text-amber-600'
                  }`}>
                    {evaluation.score}% Fit
                  </span>
                  <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                    evaluation.isWorthy ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {evaluation.verdict}
                  </span>
                </div>
              </div>

              {/* Matched skills */}
              <div className="mt-2 text-xs">
                <div className="text-slate-600 font-medium mb-1">
                  Matching Skills ({evaluation.matchedSkills.length}/{job.skills.length}):
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {evaluation.matchedSkills.map(skill => (
                    <span key={skill} className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-700 font-medium flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      {skill}
                    </span>
                  ))}
                  {evaluation.missingSkills.map(skill => (
                    <span key={skill} className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-500 text-[11px]">
                      Missing: {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Resume Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Resume Formalities & Attachment
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div 
                  onClick={() => setSelectedResumeType('profile')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedResumeType === 'profile'
                      ? 'bg-blue-50/70 border-blue-500 shadow-sm'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <FileText className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-xs font-bold text-slate-900">Use HireSphere Profile Resume</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {activeResume ? `${activeResume.fullName || 'Candidate'}'s Parsed Resume (ATS ${activeResume.atsScore}%)` : `${safeUser.fullName || 'Candidate'} - Standard Profile`}
                      </div>
                    </div>
                  </div>
                </div>

                <div 
                  onClick={() => setSelectedResumeType('custom')}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedResumeType === 'custom'
                      ? 'bg-blue-50/70 border-blue-500 shadow-sm'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <Upload className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                    <div className="w-full">
                      <div className="text-xs font-bold text-slate-900">Upload Alternative Document</div>
                      <label className="text-[11px] text-blue-600 hover:underline cursor-pointer block mt-0.5">
                        {uploadedResumeName || 'Click to select PDF/DOCX file'}
                        <input type="file" accept=".pdf,.doc,.docx,.txt" onChange={handleFileUpload} className="hidden" />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Candidate Details Confirmation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500">Applicant:</span>{' '}
                <span className="font-semibold text-slate-900">{safeUser.fullName || 'Candidate'}</span>
              </div>
              <div>
                <span className="text-slate-500">Email:</span>{' '}
                <span className="font-semibold text-slate-900">{safeUser.email || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-500">Phone:</span>{' '}
                <span className="font-semibold text-slate-900">{safeUser.phone || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-500">Location:</span>{' '}
                <span className="font-semibold text-slate-900">{safeUser.location || 'N/A'}</span>
              </div>
            </div>

            {/* Expected Salary & Notice Period */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Notice Period / Availability</label>
                <select
                  value={noticePeriod}
                  onChange={(e) => setNoticePeriod(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                >
                  <option value="Immediate (within 15 days)">Immediate (within 15 days)</option>
                  <option value="1 Month Notice">1 Month Notice</option>
                  <option value="2 Months Notice">2 Months Notice</option>
                  <option value="Serving Notice Currently">Serving Notice Currently</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Expected Compensation</label>
                <input
                  type="text"
                  value={expectedSalary}
                  onChange={(e) => setExpectedSalary(e.target.value)}
                  placeholder="e.g. ₹20,00,000 / yr"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {/* Cover Note */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Candidate Note to Recruiter
              </label>
              <textarea
                rows={4}
                value={coverNote}
                onChange={(e) => setCoverNote(e.target.value)}
                placeholder="Share your interest, relevant project highlights, and why you are qualified..."
                className="w-full bg-white border border-slate-300 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none font-mono"
              />
            </div>

            {/* Formalities Submission Footer */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>

              <button
                id="submit-formal-application-btn"
                type="submit"
                disabled={isSubmitting}
                className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-md shadow-blue-600/25 flex items-center gap-2"
              >
                {isSubmitting ? (
                  <span>Sending Application...</span>
                ) : (
                  <>
                    <span>Submit Formal Application</span>
                    <Send className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
