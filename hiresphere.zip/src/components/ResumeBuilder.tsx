import React, { useState, useEffect, useMemo } from 'react';
import { 
  Printer, 
  Save, 
  FolderOpen, 
  Trash2, 
  Download, 
  Copy, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Briefcase, 
  GraduationCap, 
  Code2, 
  Award, 
  Link as LinkIcon, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  FileText,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { ParsedResume, UserProfile, PropathResumeFields } from '../types';
import { 
  convertResumeToPropath, 
  parsePropathToResume, 
  generateExactOrderFormattedText, 
  auditResumeContent 
} from '../utils/resumeParser';
import { SAMPLE_RESUMES } from '../data/sampleResumes';

interface ResumeBuilderProps {
  initialResume?: ParsedResume;
  currentUser?: UserProfile | null;
  onSaveToProfile: (resume: ParsedResume) => void;
  onNavigateToJobs?: () => void;
}

const DEFAULT_PROPATH_DATA: PropathResumeFields = {
  template: 'modern',
  fullName: 'Mohana Asmitha',
  role: 'Full Stack Software Engineer & Cloud Architect',
  email: 'mohanaasmitha@klh.edu.in',
  phone: '+91 98765 43210',
  location: 'Hyderabad / Bengaluru, India',
  links: 'linkedin.com/in/mohana-asmitha | github.com/mohana-asmitha | mohana.dev',
  summary: 'Results-driven Full Stack Engineer with 3+ years building high-throughput web architectures, distributed microservices, and modern React/TypeScript user interfaces. Proven track record reducing API latencies by 35% and deploying enterprise cloud systems on AWS and GCP.',
  education: 'B.Tech in Computer Science & Engineering | KL University (2021 - 2025) — CGPA: 9.2/10\nHigher Secondary Education (MPC) | Sri Chaitanya Junior College (2019 - 2021) — 96.4%',
  projects: 'Nexus Cloud Distributed Job Platform [React, TypeScript, Node.js, PostgreSQL, Docker]\nHigh-performance talent acquisition portal with intelligent ATS parsing, automated skills matrix scoring, and full-stack API integration.\nLink: https://github.com/mohana-asmitha/nexus-portal\n\nAI Stream Real-Time Pipeline [Python, FastAPI, Redis, Kafka, PyTorch]\nAsynchronous distributed data pipeline processing 15,000+ events/sec with sub-50ms inference latency.',
  experience: 'Software Development Engineer Intern — Nexus Cloud Technologies (Jan 2024 - Present)\n• Architected and shipped 14+ responsive React/TypeScript modules reducing user drop-off by 22%.\n• Optimized PostgreSQL queries and Redis caching layers, achieving a 35% latency reduction under load.\n• Spearheaded automated CI/CD pipeline using GitHub Actions and Docker containers.\n\nJunior Full Stack Developer — Apex Digital Solutions (Jun 2023 - Dec 2023)\n• Engineered RESTful APIs and webhooks handling 250,000+ daily requests with 99.9% uptime.\n• Implemented secure JWT authentication and role-based access control across enterprise dashboards.',
  skills: 'React, TypeScript, Next.js, JavaScript, Node.js, Express, Python, FastAPI, PostgreSQL, MySQL, Redis, Docker, Kubernetes, AWS, Git, REST APIs, System Design, Agile, Code Review',
  certs: 'AWS Certified Cloud Practitioner (2024)\nMeta Certified Front-End Developer Specialization (2023)\nPostgreSQL Query Optimization & Database Architecture (2023)'
};

export const ResumeBuilder: React.FC<ResumeBuilderProps> = ({
  initialResume,
  currentUser,
  onSaveToProfile,
  onNavigateToJobs
}) => {
  // 1. Exact Field State matching user's ProPath Model
  const [fields, setFields] = useState<PropathResumeFields>(() => {
    // Check localStorage first
    try {
      const saved = localStorage.getItem('propath_resume_data');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Error reading propath_resume_data', e);
    }

    if (initialResume) {
      return convertResumeToPropath(initialResume);
    }

    return DEFAULT_PROPATH_DATA;
  });

  // UI Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  const showNotification = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Convert current ProPath fields to structured ParsedResume for ATS evaluation & Job search
  const currentParsedResume = useMemo(() => {
    return parsePropathToResume(fields);
  }, [fields]);

  // Live ATS Quality Audit
  const audit = useMemo(() => {
    const raw = `${fields.fullName}\n${fields.role}\n${fields.summary}\n${fields.skills}\n${fields.experience}\n${fields.education}`;
    return auditResumeContent(raw, currentParsedResume);
  }, [fields, currentParsedResume]);

  // Handle Input Changes (Live update on input & change)
  const handleFieldChange = (key: keyof PropathResumeFields, value: string) => {
    setFields(prev => ({
      ...prev,
      [key]: value
    }));
  };

  // Helper setData matching user's snippet
  const setData = (data: Partial<PropathResumeFields> | null) => {
    if (!data) return;
    setFields(prev => ({
      ...prev,
      ...data,
      template: data.template || prev.template || 'modern'
    }));
  };

  // Helper getData matching user's snippet
  const getData = (): PropathResumeFields => {
    return fields;
  };

  // Button 1: btnPrint - window.print()
  const handlePrint = () => {
    window.print();
  };

  // Button 2: btnSave - saves to localStorage & active profile
  const handleSave = () => {
    try {
      const data = getData();
      localStorage.setItem('propath_resume_data', JSON.stringify(data));
      const parsed = parsePropathToResume(data);
      onSaveToProfile(parsed);
      showNotification('Resume successfully saved to ProPath Storage & synced with your Profile!');
      // Also invoke native alert if desired, with friendly UI banner
    } catch (e) {
      console.error('Error saving resume', e);
    }
  };

  // Button 3: btnLoad - reads from localStorage
  const handleLoad = () => {
    try {
      const raw = localStorage.getItem('propath_resume_data');
      if (!raw) {
        alert('No saved data found in ProPath Storage.');
        return;
      }
      const parsed = JSON.parse(raw);
      setData(parsed);
      showNotification('Saved ProPath Resume successfully loaded!');
    } catch (e) {
      console.error('Error loading resume', e);
      alert('Error loading saved data.');
    }
  };

  // Button 4: btnClear - confirm and clear
  const handleClear = () => {
    if (!confirm('Clear all fields? This will reset the resume.')) return;
    setData({
      template: 'modern',
      fullName: '',
      role: '',
      email: '',
      phone: '',
      location: '',
      links: '',
      summary: '',
      education: '',
      projects: '',
      experience: '',
      skills: '',
      certs: ''
    });
    localStorage.removeItem('propath_resume_data');
    showNotification('All fields cleared.');
  };

  // Load User Profile Data
  const handleLoadProfileData = () => {
    if (!currentUser) return;
    setData({
      fullName: currentUser.fullName || fields.fullName,
      role: currentUser.title || fields.role,
      email: currentUser.email || fields.email,
      phone: currentUser.phone || fields.phone,
      location: currentUser.location || fields.location,
      summary: currentUser.summary || fields.summary,
      skills: currentUser.skills?.join(', ') || fields.skills
    });
    showNotification(`Loaded information from ${currentUser?.fullName || 'User'}'s profile.`);
  };

  // Load Presets
  const handleLoadPreset = (key: keyof typeof SAMPLE_RESUMES) => {
    const sample = SAMPLE_RESUMES[key];
    if (sample) {
      setData(convertResumeToPropath(sample));
      showNotification(`Loaded ${sample.fullName}'s standard ATS resume.`);
    }
  };

  // Download Exact Text Format (.txt)
  const handleDownloadTxt = () => {
    const text = generateExactOrderFormattedText(currentParsedResume);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fields.fullName.replace(/\s+/g, '_')}_ATS_Resume.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showNotification('Exact ATS Formatted Text file downloaded!');
  };

  // Download JSON Schema
  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(fields, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fields.fullName.replace(/\s+/g, '_')}_ProPath_Data.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showNotification('JSON Resume file downloaded!');
  };

  // Copy Exact Text
  const handleCopyExactText = () => {
    const text = generateExactOrderFormattedText(currentParsedResume);
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
    showNotification('Formatted ATS Text copied to clipboard!');
  };

  // Set as Active Application Resume & Go To Jobs
  const handleUseForJobs = () => {
    handleSave();
    if (onNavigateToJobs) {
      onNavigateToJobs();
    }
  };

  return (
    <div id="resume-builder-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Printable Style Sheet for crisp print-out */}
      <style>{`
        @media print {
          body {
            background: white !important;
            color: black !important;
          }
          #main-header,
          #mobile-nav-bar,
          .no-print,
          footer {
            display: none !important;
          }
          #resume-live-preview-container {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
            border: none !important;
          }
          .resume-sheet {
            box-shadow: none !important;
            border: none !important;
            padding: 0 !important;
          }
        }
      `}</style>

      {/* Top Banner with ProPath Controls */}
      <div className="bg-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2 text-xs text-blue-400 font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Interactive ProPath ATS Resume Builder</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            Build, Edit & Download Exact Model Resume
          </h1>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl">
            Live real-time updates as you type. Formats and persists your resume in the exact order demanded by corporate ATS filters and technical recruiters.
          </p>
        </div>

        {/* Action Controls matching User Snippet IDs */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* btnPrint: window.print() */}
          <button
            id="btnPrint"
            onClick={handlePrint}
            className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all shadow-lg shadow-blue-600/30 flex items-center gap-1.5"
            title="Print or Save as PDF"
          >
            <Printer className="w-4 h-4" />
            <span>Print / PDF</span>
          </button>

          {/* btnSave: localStorage & profile */}
          <button
            id="btnSave"
            onClick={handleSave}
            className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/30 flex items-center gap-1.5"
            title="Save to ProPath localStorage & Profile"
          >
            <Save className="w-4 h-4" />
            <span>Save</span>
          </button>

          {/* btnLoad: load from localStorage */}
          <button
            id="btnLoad"
            onClick={handleLoad}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Load saved resume from ProPath storage"
          >
            <FolderOpen className="w-4 h-4 text-amber-400" />
            <span>Load</span>
          </button>

          {/* btnClear: clear all fields */}
          <button
            id="btnClear"
            onClick={handleClear}
            className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-red-950 text-slate-300 hover:text-red-300 border border-slate-700 hover:border-red-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Clear all fields"
          >
            <Trash2 className="w-4 h-4 text-red-400" />
            <span>Clear</span>
          </button>

          {/* Use For Jobs CTA */}
          <button
            id="btnUseForJobs"
            onClick={handleUseForJobs}
            className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            title="Set as active resume and browse 25+ matching vacancies"
          >
            <Briefcase className="w-4 h-4" />
            <span>Apply to Jobs With This Resume</span>
          </button>
        </div>
      </div>

      {/* Floating Notification Toast */}
      {toastMessage && (
        <div className="bg-slate-900 border border-blue-500/40 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2 no-print">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Secondary Bar: Template Selector & Pre-fill Helpers */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-wrap items-center justify-between gap-4 text-xs no-print">
        <div className="flex items-center gap-3">
          <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
            Resume Layout Template:
          </span>
          <select
            id="templateSelect"
            value={fields.template}
            onChange={(e) => handleFieldChange('template', e.target.value as any)}
            className="bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 font-semibold text-slate-800 focus:outline-none focus:border-blue-500"
          >
            <option value="modern">Modern Professional (Recommended)</option>
            <option value="minimal">Minimal ATS Plain Text</option>
            <option value="executive">Executive Corporate</option>
            <option value="tech_ats">Technical Engineering ATS</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 hidden sm:inline">Quick Pre-fills:</span>
          <button
            onClick={handleLoadProfileData}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium"
          >
            Load My Profile
          </button>
          <button
            onClick={() => handleLoadPreset('mohana')}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium"
          >
            Sample: Mohana (SDE)
          </button>
          <button
            onClick={() => handleLoadPreset('vikram')}
            className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium"
          >
            Sample: Cloud Lead
          </button>
        </div>
      </div>

      {/* Main Grid: Left Editor & Right Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Input Form (5 cols on lg) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 no-print">
          
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Resume Content Editor</h3>
              <p className="text-[11px] text-slate-500">Changes reflect instantly in the exact preview.</p>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold">
              <span>ATS Score: {audit.score}%</span>
            </div>
          </div>

          {/* 1. Personal & Contact Info */}
          <div className="space-y-3">
            <div className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-600" />
              <span>1. Contact & Identification</span>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                id="fullName"
                type="text"
                value={fields.fullName}
                onChange={(e) => handleFieldChange('fullName', e.target.value)}
                placeholder="e.g. Mohana Asmitha"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Target Professional Role / Title</label>
              <input
                id="role"
                type="text"
                value={fields.role}
                onChange={(e) => handleFieldChange('role', e.target.value)}
                placeholder="e.g. Full Stack Software Engineer"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Email Address</label>
                <input
                  id="email"
                  type="email"
                  value={fields.email}
                  onChange={(e) => handleFieldChange('email', e.target.value)}
                  placeholder="mohanaasmitha@klh.edu.in"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Phone Number</label>
                <input
                  id="phone"
                  type="text"
                  value={fields.phone}
                  onChange={(e) => handleFieldChange('phone', e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Location / City, Country</label>
                <input
                  id="location"
                  type="text"
                  value={fields.location}
                  onChange={(e) => handleFieldChange('location', e.target.value)}
                  placeholder="Hyderabad, India"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Links (LinkedIn | GitHub | Portfolio)</label>
                <input
                  id="links"
                  type="text"
                  value={fields.links}
                  onChange={(e) => handleFieldChange('links', e.target.value)}
                  placeholder="linkedin.com/in/mohana | github.com/mohana"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* 2. Professional Summary */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span>2. Executive Summary</span>
            </label>
            <textarea
              id="summary"
              rows={3}
              value={fields.summary}
              onChange={(e) => handleFieldChange('summary', e.target.value)}
              placeholder="Concise overview summarizing your core engineering expertise, key achievements, and domain focus..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500 leading-relaxed"
            />
          </div>

          {/* 3. Skills */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Code2 className="w-3.5 h-3.5 text-blue-600" />
              <span>3. Technical & Professional Skills (Comma-separated)</span>
            </label>
            <textarea
              id="skills"
              rows={2}
              value={fields.skills}
              onChange={(e) => handleFieldChange('skills', e.target.value)}
              placeholder="React, TypeScript, Python, FastAPI, PostgreSQL, Docker, AWS, System Design, Git"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* 4. Experience */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-blue-600" />
              <span>4. Professional Experience</span>
            </label>
            <div className="text-[10px] text-slate-500 mb-1">
              Format: Title — Company (Duration) followed by • Bullet points with metrics.
            </div>
            <textarea
              id="experience"
              rows={5}
              value={fields.experience}
              onChange={(e) => handleFieldChange('experience', e.target.value)}
              placeholder="Software Engineer — Tech Corp (2023 - Present)&#10;• Architected distributed services improving response times by 35%.&#10;• Built responsive UI features in React and TypeScript."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500 font-mono text-[11px]"
            />
          </div>

          {/* 5. Education */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
              <span>5. Education & Academic Background</span>
            </label>
            <textarea
              id="education"
              rows={2}
              value={fields.education}
              onChange={(e) => handleFieldChange('education', e.target.value)}
              placeholder="B.Tech in Computer Science | University (2021 - 2025) — CGPA: 9.0"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* 6. Projects */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Code2 className="w-3.5 h-3.5 text-blue-600" />
              <span>6. Key Projects</span>
            </label>
            <textarea
              id="projects"
              rows={4}
              value={fields.projects}
              onChange={(e) => handleFieldChange('projects', e.target.value)}
              placeholder="Project Name [Tech, Stack]&#10;Description of the project engineering solution.&#10;Link: https://..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500 font-mono text-[11px]"
            />
          </div>

          {/* 7. Certifications */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-blue-600" />
              <span>7. Certifications & Accreditations</span>
            </label>
            <textarea
              id="certs"
              rows={2}
              value={fields.certs}
              onChange={(e) => handleFieldChange('certs', e.target.value)}
              placeholder="AWS Certified Cloud Practitioner&#10;Meta Certified Frontend Developer"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-900 focus:bg-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Quick Quality Summary */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700">ATS Optimization Check:</span>
              <span className="font-bold text-emerald-600">{audit.score}/100</span>
            </div>
            <div className="text-[11px] text-slate-500">
              {audit.criticalIssues.length === 0 ? (
                <span className="text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  All mandatory contact and content sections verified.
                </span>
              ) : (
                <span className="text-amber-700">
                  {audit.criticalIssues.length} suggestion(s) detected. Check fields above.
                </span>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Live Exact Model Preview (7 cols on lg) */}
        <div id="resume-live-preview-container" className="lg:col-span-7 space-y-4">
          
          {/* Format & Download Bar */}
          <div className="bg-white rounded-xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3 text-xs shadow-xs no-print">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="font-bold text-slate-800">Live Exact Model Preview</span>
              <span className="text-slate-400">|</span>
              <span className="text-slate-500 capitalize">{fields.template} Style</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="btnDownloadTxt"
                onClick={handleDownloadTxt}
                className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                title="Download plain text adhering to exact corporate ATS ordering"
              >
                <Download className="w-3.5 h-3.5 text-blue-600" />
                <span>Download .TXT</span>
              </button>

              <button
                id="btnDownloadJson"
                onClick={handleDownloadJson}
                className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                title="Download JSON structured schema"
              >
                <Download className="w-3.5 h-3.5 text-purple-600" />
                <span>JSON</span>
              </button>

              <button
                onClick={handleCopyExactText}
                className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold flex items-center gap-1.5 transition-colors"
                title="Copy formatted text to clipboard"
              >
                <Copy className="w-3.5 h-3.5 text-slate-600" />
                <span>{copiedText ? 'Copied!' : 'Copy Text'}</span>
              </button>

              <button
                onClick={handlePrint}
                className="py-1.5 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1.5 transition-colors shadow-sm"
                title="Open browser print dialog to print or save as PDF"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / PDF</span>
              </button>
            </div>
          </div>

          {/* THE RESUME DOCUMENT SHEET (Exact Model) */}
          <div 
            id="resume-document-sheet"
            className={`resume-sheet bg-white rounded-2xl border border-slate-300 shadow-md p-8 sm:p-10 transition-all ${
              fields.template === 'minimal' ? 'font-serif text-slate-900' : 'font-sans'
            }`}
          >
            {/* Header / Identification */}
            <div className={`pb-6 mb-6 ${
              fields.template === 'modern' ? 'border-b-2 border-blue-600' :
              fields.template === 'executive' ? 'border-b-2 border-slate-900 bg-slate-900 text-white -mx-8 -mt-8 sm:-mx-10 sm:-mt-10 p-8 rounded-t-2xl' :
              'border-b border-slate-300 text-center'
            }`}>
              <h1 className={`text-2xl sm:text-3xl font-bold tracking-tight ${
                fields.template === 'executive' ? 'text-white' : 'text-slate-900'
              }`}>
                {fields.fullName || 'Candidate Full Name'}
              </h1>
              
              <div className={`text-sm font-semibold mt-1 ${
                fields.template === 'executive' ? 'text-blue-300' : 'text-blue-600'
              }`}>
                {fields.role || 'Software Engineering Professional'}
              </div>

              {/* Contact Line */}
              <div className={`flex flex-wrap items-center gap-x-4 gap-y-1 text-xs mt-3 ${
                fields.template === 'executive' ? 'text-slate-300' : 'text-slate-600'
              }`}>
                {fields.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 opacity-70" />
                    {fields.email}
                  </span>
                )}
                {fields.phone && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 opacity-70" />
                    {fields.phone}
                  </span>
                )}
                {fields.location && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 opacity-70" />
                    {fields.location}
                  </span>
                )}
              </div>

              {/* Links Line */}
              {fields.links && (
                <div className={`text-xs mt-2 flex items-center gap-1.5 ${
                  fields.template === 'executive' ? 'text-blue-300' : 'text-blue-700'
                }`}>
                  <LinkIcon className="w-3.5 h-3.5 opacity-75 shrink-0" />
                  <span className="font-mono text-[11px]">{fields.links}</span>
                </div>
              )}
            </div>

            {/* Resume Body Content in Exact Corporate Sequence */}
            <div className="space-y-6 text-xs text-slate-800 leading-relaxed">
              
              {/* 1. PROFESSIONAL SUMMARY */}
              {fields.summary && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-2 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Professional Summary
                  </h2>
                  <p className="text-slate-700 leading-relaxed whitespace-pre-line">
                    {fields.summary}
                  </p>
                </div>
              )}

              {/* 2. TECHNICAL & PROFESSIONAL SKILLS */}
              {fields.skills && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-2 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Core Competencies & Technical Skills
                  </h2>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {fields.skills.split(/[,;\n]+/).map((s, idx) => {
                      const trimmed = s.trim();
                      if (!trimmed) return null;
                      return (
                        <span 
                          key={idx}
                          className={`px-2 py-0.5 rounded text-[11px] font-medium ${
                            fields.template === 'minimal'
                              ? 'border border-slate-300 text-slate-800'
                              : 'bg-slate-100 text-slate-800 border border-slate-200'
                          }`}
                        >
                          {trimmed}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 3. WORK EXPERIENCE */}
              {fields.experience && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-3 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Work Experience
                  </h2>
                  <div className="space-y-4">
                    {fields.experience.split(/\n\n+/).map((block, idx) => {
                      const lines = block.split('\n').filter(Boolean);
                      if (lines.length === 0) return null;
                      const titleLine = lines[0];
                      const bullets = lines.slice(1);

                      return (
                        <div key={idx} className="space-y-1.5">
                          <div className="font-bold text-slate-900 text-xs">
                            {titleLine}
                          </div>
                          {bullets.length > 0 && (
                            <ul className="space-y-1 pl-4 list-disc marker:text-slate-400">
                              {bullets.map((b, bIdx) => (
                                <li key={bIdx} className="text-slate-700">
                                  {b.replace(/^[•*-]\s*/, '')}
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 4. EDUCATION */}
              {fields.education && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-2 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Education & Credentials
                  </h2>
                  <div className="space-y-2">
                    {fields.education.split('\n').filter(Boolean).map((line, idx) => (
                      <div key={idx} className="text-slate-800 font-medium">
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 5. PROJECTS */}
              {fields.projects && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-3 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Technical Projects & Solutions
                  </h2>
                  <div className="space-y-3">
                    {fields.projects.split(/\n\n+/).map((pBlock, idx) => {
                      const pLines = pBlock.split('\n').filter(Boolean);
                      if (pLines.length === 0) return null;
                      const header = pLines[0];
                      const details = pLines.slice(1);

                      return (
                        <div key={idx} className="space-y-1">
                          <div className="font-bold text-slate-900 text-xs">
                            {header}
                          </div>
                          {details.map((d, dIdx) => (
                            <div key={dIdx} className="text-slate-700 pl-2">
                              {d.startsWith('Link:') ? (
                                <span className="text-blue-600 font-mono text-[11px] flex items-center gap-1">
                                  <ExternalLink className="w-3 h-3" />
                                  {d}
                                </span>
                              ) : (
                                d
                              )}
                            </div>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 6. CERTIFICATIONS */}
              {fields.certs && (
                <div>
                  <h2 className={`text-xs font-bold uppercase tracking-wider mb-2 pb-1 border-b ${
                    fields.template === 'modern' ? 'text-blue-800 border-blue-100' : 'text-slate-900 border-slate-200'
                  }`}>
                    Certifications & Accreditations
                  </h2>
                  <div className="space-y-1">
                    {fields.certs.split('\n').filter(Boolean).map((cert, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-slate-700">
                        <Award className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span>{cert.replace(/^[•*-]\s*/, '')}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Print Footer Details */}
            <div className="mt-8 pt-4 border-t border-slate-200 text-[10px] text-slate-400 flex items-center justify-between">
              <span>Standard ATS Machine-Readable Curriculum Vitae</span>
              <span>HireSphere Integrated Career Suite</span>
            </div>

          </div>

          {/* Bottom Confirmation Banner */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs no-print">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
              <div>
                <div className="font-bold text-blue-900">Resume Ready for 25+ Matching Vacancies</div>
                <div className="text-blue-700 text-[11px]">
                  This resume is active. Recruiters can view its exact content when you apply.
                </div>
              </div>
            </div>

            <button
              onClick={handleUseForJobs}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm whitespace-nowrap transition-colors flex items-center gap-1.5"
            >
              <span>Explore Matching Jobs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
