import React, { useState } from 'react';
import { Briefcase, Lock, Mail, ArrowRight, UserCheck, ShieldCheck, Sparkles, Building, Code, X } from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { INITIAL_CANDIDATE_PROFILE, INITIAL_RECRUITER_PROFILE, SAMPLE_PROFILES } from '../data/sampleResumes';

export interface AuthModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSuccess?: (user: UserProfile) => void;
  onAuthSuccess?: (user: UserProfile) => void;
  registeredUsers?: Record<string, UserProfile>;
}

export const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen = true,
  onClose,
  onSuccess, 
  onAuthSuccess,
  registeredUsers 
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Sign up career details step
  const [signUpStep, setSignUpStep] = useState<1 | 2>(1);
  const [role, setRole] = useState<UserRole>('jobseeker');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [title, setTitle] = useState('');
  const [experienceYears, setExperienceYears] = useState(2);
  const [experienceLevel, setExperienceLevel] = useState<'Entry Level' | 'Mid Level' | 'Senior' | 'Lead'>('Mid Level');
  const [skillsInput, setSkillsInput] = useState('React, TypeScript, PostgreSQL, Python, REST APIs');
  const [interestsInput, setInterestsInput] = useState('Full Stack, Database Systems, AI Matching');
  const [degree, setDegree] = useState('B.Tech in Computer Science');
  const [institution, setInstitution] = useState('Koneru Lakshmaiah Education Foundation');
  const [companyName, setCompanyName] = useState('Tech Solutions Corp');

  // If explicitly closed, do not render
  if (isOpen === false) return null;

  // Unified callback dispatcher
  const handleSuccessCallback = (user: UserProfile) => {
    if (onAuthSuccess) onAuthSuccess(user);
    if (onSuccess) onSuccess(user);
    if (onClose) onClose();
  };

  // Build comprehensive registered user dictionary safely
  const getUserDictionary = (): Record<string, UserProfile> => {
    const userDict: Record<string, UserProfile> = {
      [INITIAL_CANDIDATE_PROFILE.email.toLowerCase()]: INITIAL_CANDIDATE_PROFILE,
      [INITIAL_RECRUITER_PROFILE.email.toLowerCase()]: INITIAL_RECRUITER_PROFILE,
      'vikram@nexuscloud.io': INITIAL_RECRUITER_PROFILE,
      ...(registeredUsers || {})
    };

    if (Array.isArray(SAMPLE_PROFILES)) {
      for (const p of SAMPLE_PROFILES) {
        if (p?.email) {
          userDict[p.email.toLowerCase()] = p;
        }
      }
    }

    try {
      const stored = localStorage.getItem('hiresphere_registered_users');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object') {
          Object.assign(userDict, parsed);
        }
      }
    } catch (err) {
      console.warn('Could not read stored users from storage', err);
    }

    return userDict;
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail || !password) {
      setError('Please provide both email ID and password.');
      return;
    }

    // Safely check user in dictionary
    const allUsers = getUserDictionary();
    const existing = allUsers[trimmedEmail];

    if (existing) {
      if (existing.password && password && existing.password !== password) {
        setError('Incorrect password. Please try again.');
        return;
      }
      handleSuccessCallback(existing);
    } else {
      // First time sign-in: switch to career details registration to save credentials
      setMode('signup');
      setSignUpStep(2);
      setEmail(trimmedEmail);
      setError('This email is not registered yet. Complete your career profile below to register your account.');
    }
  };

  const handleSignUpNext = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail || !password) {
      setError('Please provide a valid email ID and password.');
      return;
    }
    if (password.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }

    // Proceed to professional career questionnaire
    setSignUpStep(2);
  };

  const handleCompleteSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('Please provide your full name.');
      return;
    }

    const trimmedEmail = email.trim().toLowerCase();
    const parsedSkills = skillsInput.split(',').map(s => s.trim()).filter(Boolean);
    const parsedInterests = interestsInput.split(',').map(s => s.trim()).filter(Boolean);

    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      email: trimmedEmail,
      password: password,
      role: role,
      fullName: fullName.trim(),
      phone: phone.trim() || '+91 98765 43210',
      location: location.trim() || 'Hyderabad, India',
      title: title.trim() || (role === 'recruiter' ? 'Technical Talent Recruiter' : 'Software Engineer'),
      summary: role === 'recruiter' 
        ? `Recruiting leader at ${companyName}, sourcing talented engineers for high-impact teams.`
        : `Motivated professional specializing in ${title || 'modern software engineering'} with strong skills in ${parsedSkills.slice(0, 3).join(', ')}.`,
      experienceYears: Number(experienceYears),
      experienceLevel: experienceLevel,
      skills: parsedSkills.length > 0 ? parsedSkills : ['React', 'TypeScript', 'PostgreSQL', 'Python'],
      interests: parsedInterests.length > 0 ? parsedInterests : ['Full Stack Development', 'Database Engineering'],
      education: [
        {
          degree: degree || 'B.Tech in Computer Science',
          institution: institution || 'University College of Engineering',
          year: '2023 - 2027'
        }
      ],
      workHistory: [
        {
          role: title || 'Software Engineer',
          company: role === 'recruiter' ? companyName : 'Tech Innovations',
          duration: '2024 - Present',
          description: 'Actively contributing to scalable engineering and systems workflows.'
        }
      ],
      certifications: ['Certified Professional in Modern Web & Cloud Systems'],
      portfolioLinks: {},
      companyName: role === 'recruiter' ? companyName : undefined,
      companyRole: role === 'recruiter' ? 'Talent Acquisition' : undefined,
      createdAt: new Date().toISOString().split('T')[0]
    };

    // Save to localStorage registered users
    try {
      const stored = localStorage.getItem('hiresphere_registered_users');
      const parsed = stored ? JSON.parse(stored) : {};
      parsed[trimmedEmail] = newUser;
      localStorage.setItem('hiresphere_registered_users', JSON.stringify(parsed));
    } catch (err) {
      console.warn('Could not save user to storage', err);
    }

    handleSuccessCallback(newUser);
  };

  // Demo 1-Click logins
  const handleQuickCandidate = () => {
    handleSuccessCallback(INITIAL_CANDIDATE_PROFILE);
  };

  const handleQuickRecruiter = () => {
    handleSuccessCallback(INITIAL_RECRUITER_PROFILE);
  };

  return (
    <div 
      id="auth-modal-overlay" 
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && onClose) {
          onClose();
        }
      }}
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div 
        id="auth-modal-content" 
        className="w-full max-w-xl bg-slate-900 border border-slate-800 shadow-2xl rounded-2xl p-6 sm:p-8 relative z-10 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200"
      >
        {onClose && (
          <button
            id="auth-modal-close-btn"
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        )}
        
        {/* Header: HireSphere: An Integrated Job Portal with Resume Parsing */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-600 text-white shadow-lg shadow-blue-500/25 mb-3">
            <Briefcase className="w-6 h-6" />
          </div>
          <h1 id="auth-portal-title" className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
            HireSphere: An Integrated Job Portal with Resume Parsing
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Automating candidate-recruiter discovery, intelligent skill matching & resume parsing
          </p>
        </div>

        {/* Tab Switcher: Sign In vs First-Time Sign Up */}
        <div className="flex rounded-xl bg-slate-800/80 p-1 mb-6 border border-slate-700/60">
          <button
            id="tab-signin-btn"
            type="button"
            onClick={() => {
              setMode('signin');
              setSignUpStep(1);
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
              mode === 'signin'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Log In (Existing Account)
          </button>
          <button
            id="tab-signup-btn"
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
            }}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${
              mode === 'signup'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Sign Up (First Time)
          </button>
        </div>

        {error && (
          <div id="auth-error-box" className="mb-5 p-3 rounded-lg bg-red-950/70 border border-red-800 text-red-200 text-xs font-medium leading-relaxed">
            {error}
          </div>
        )}

        {/* Mode 1: Sign In Form */}
        {mode === 'signin' && (
          <form id="signin-form" onSubmit={handleSignIn} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="signin-email-input"
                  type="email"
                  required
                  placeholder="e.g. mohanaasmitha@klh.edu.in"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-800/90 border border-slate-700 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="signin-password-input"
                  type="password"
                  required
                  placeholder="Enter your account password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-800/90 border border-slate-700 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                If this is your first time, your credentials will automatically prompt career profile setup.
              </p>
            </div>

            <button
              id="signin-submit-btn"
              type="submit"
              className="w-full mt-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-colors shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
            >
              <span>Access HireSphere Portal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Mode 2: Sign Up (First Time Sign In) with Career Details */}
        {mode === 'signup' && (
          <div>
            {signUpStep === 1 ? (
              <form id="signup-step1-form" onSubmit={handleSignUpNext} className="space-y-4">
                <div className="p-3 bg-blue-950/40 border border-blue-800/50 rounded-xl text-blue-200 text-xs">
                  <p className="font-semibold text-white mb-0.5">First-Time Account Registration</p>
                  Create your login credentials. On the next screen, we will collect your professional career & experience details to assist recruiters.
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Account Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      id="signup-email-input"
                      type="email"
                      required
                      placeholder="e.g. name@domain.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-800/90 border border-slate-700 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Choose Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      id="signup-password-input"
                      type="password"
                      required
                      placeholder="Create a secure password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-800/90 border border-slate-700 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
                    />
                  </div>
                </div>

                <button
                  id="signup-next-btn"
                  type="submit"
                  className="w-full mt-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm transition-colors shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
                >
                  <span>Continue to Career Experience Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <form id="signup-step2-career-form" onSubmit={handleCompleteSignUp} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
                <div className="p-3 bg-slate-800/80 border border-slate-700 rounded-xl text-xs text-slate-300">
                  <span className="font-bold text-white">Professional Career Details:</span> This establishes your skills profile for automated recruiter matching and resume scoring.
                </div>

                {/* Role selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">Select Primary Role</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      id="role-jobseeker-btn"
                      onClick={() => setRole('jobseeker')}
                      className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                        role === 'jobseeker'
                          ? 'bg-blue-600/20 border-blue-500 text-white'
                          : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      <UserCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-white">Job Seeker</div>
                        <div className="text-[11px] text-slate-400">Search jobs, build & parse resumes</div>
                      </div>
                    </button>

                    <button
                      type="button"
                      id="role-recruiter-btn"
                      onClick={() => setRole('recruiter')}
                      className={`p-3 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                        role === 'recruiter'
                          ? 'bg-purple-600/20 border-purple-500 text-white'
                          : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:border-slate-600'
                      }`}
                    >
                      <Building className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-xs font-bold text-white">Job Recruiter</div>
                        <div className="text-[11px] text-slate-400">Post jobs, evaluate candidates</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Full Name & Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                    <input
                      id="signup-fullname-input"
                      type="text"
                      required
                      placeholder="e.g. M. Mohana Asmitha"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Phone Number</label>
                    <input
                      id="signup-phone-input"
                      type="text"
                      placeholder="+91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Professional Title & Location */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      {role === 'recruiter' ? 'Company Name' : 'Professional Title'}
                    </label>
                    <input
                      id="signup-title-input"
                      type="text"
                      placeholder={role === 'recruiter' ? 'e.g. Nexus Cloud Tech' : 'e.g. Full Stack & Database Engineer'}
                      value={role === 'recruiter' ? companyName : title}
                      onChange={(e) => role === 'recruiter' ? setCompanyName(e.target.value) : setTitle(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Location</label>
                    <input
                      id="signup-location-input"
                      type="text"
                      placeholder="e.g. Hyderabad, India"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Experience Years & Level */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Years of Experience</label>
                    <input
                      id="signup-expyears-input"
                      type="number"
                      min={0}
                      max={30}
                      value={experienceYears}
                      onChange={(e) => setExperienceYears(Number(e.target.value))}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Experience Level</label>
                    <select
                      id="signup-explevel-select"
                      value={experienceLevel}
                      onChange={(e) => setExperienceLevel(e.target.value as any)}
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    >
                      <option value="Entry Level">Entry Level (0-1 yrs)</option>
                      <option value="Mid Level">Mid Level (2-4 yrs)</option>
                      <option value="Senior">Senior (5-8 yrs)</option>
                      <option value="Lead">Lead / Architect (8+ yrs)</option>
                    </select>
                  </div>
                </div>

                {/* Skills input */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Key Technical & Career Skills (comma separated)
                  </label>
                  <input
                    id="signup-skills-input"
                    type="text"
                    value={skillsInput}
                    onChange={(e) => setSkillsInput(e.target.value)}
                    placeholder="React, TypeScript, PostgreSQL, Python, Docker"
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Our matching algorithm uses these skills to calculate match compatibility scores for job openings.
                  </p>
                </div>

                {/* Education */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Degree / Qualification</label>
                    <input
                      id="signup-degree-input"
                      type="text"
                      value={degree}
                      onChange={(e) => setDegree(e.target.value)}
                      placeholder="B.Tech in Computer Science"
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">College / University</label>
                    <input
                      id="signup-institution-input"
                      type="text"
                      value={institution}
                      onChange={(e) => setInstitution(e.target.value)}
                      placeholder="KL University"
                      className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSignUpStep(1)}
                    className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                  >
                    Back
                  </button>
                  <button
                    id="signup-complete-btn"
                    type="submit"
                    className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2"
                  >
                    <span>Save Details & Enter Portal</span>
                    <ShieldCheck className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* 1-Click Quick Demo Access */}
        <div className="mt-6 pt-5 border-t border-slate-800/90 text-center">
          <p className="text-xs text-slate-400 mb-3 font-medium">
            Fast Preview: Test immediately with pre-configured accounts
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              id="quick-candidate-demo-btn"
              type="button"
              onClick={handleQuickCandidate}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
            >
              <Code className="w-4 h-4 text-blue-400" />
              <span>Candidate: M. Mohana Asmitha</span>
            </button>

            <button
              id="quick-recruiter-demo-btn"
              type="button"
              onClick={handleQuickRecruiter}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-2 transition-colors"
            >
              <Building className="w-4 h-4 text-purple-400" />
              <span>Recruiter: Vikramaditya Rao</span>
            </button>
          </div>

          {onClose && (
            <button
              id="guest-browse-btn"
              type="button"
              onClick={onClose}
              className="mt-3 text-xs text-slate-400 hover:text-slate-200 underline underline-offset-4 transition-colors"
            >
              Or explore job catalog as guest first →
            </button>
          )}
        </div>

      </div>

      <div className="mt-6 text-center text-xs text-slate-500">
        HireSphere Database Systems Engineering & Distributed Recruitment Architecture
      </div>
    </div>
  );
};
