/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { JobSearch } from './components/JobSearch';
import { ApplyModal } from './components/ApplyModal';
import { RecruiterPortal } from './components/RecruiterPortal';
import { ResumeBuilder } from './components/ResumeBuilder';
import { ResumeParser } from './components/ResumeParser';
import { ProfileView } from './components/ProfileView';
import { ProfileEditorModal } from './components/ProfileEditorModal';
import { INITIAL_JOBS } from './data/mockJobs';
import { SAMPLE_PROFILES, SAMPLE_RESUMES, INITIAL_APPLICATIONS, INITIAL_CANDIDATE_PROFILE, INITIAL_RECRUITER_PROFILE } from './data/sampleResumes';
import { UserProfile, Job, JobApplication, ParsedResume } from './types';

export default function App() {
  // Current user state with local storage fallback
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const savedUser = localStorage.getItem('hiresphere_active_user');
      if (savedUser) return JSON.parse(savedUser);
    } catch (e) {
      console.error('Error reading active user from localStorage', e);
    }
    // Return null when first opening so authentication gate is shown
    return null;
  });

  // Auth modal visibility: display login/auth page immediately on first open if no saved session
  const [showAuthModal, setShowAuthModal] = useState<boolean>(() => {
    try {
      const savedUser = localStorage.getItem('hiresphere_active_user');
      return !savedUser;
    } catch {
      return true;
    }
  });

  // Registered user accounts database in memory & localStorage
  const [registeredUsers, setRegisteredUsers] = useState<Record<string, UserProfile>>(() => {
    const map: Record<string, UserProfile> = {
      [INITIAL_CANDIDATE_PROFILE.email.toLowerCase()]: INITIAL_CANDIDATE_PROFILE,
      [INITIAL_RECRUITER_PROFILE.email.toLowerCase()]: INITIAL_RECRUITER_PROFILE,
      'vikram@nexuscloud.io': INITIAL_RECRUITER_PROFILE,
    };
    for (const p of SAMPLE_PROFILES) {
      if (p.email) map[p.email.toLowerCase()] = p;
    }
    try {
      const saved = localStorage.getItem('hiresphere_registered_users');
      if (saved) Object.assign(map, JSON.parse(saved));
    } catch (e) {
      console.warn('Error reading registered users from storage', e);
    }
    return map;
  });

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<'jobs' | 'recruiter' | 'resume-builder' | 'resume-parser' | 'profile'>('jobs');

  // Job Catalog State
  const [jobs, setJobs] = useState<Job[]>(() => {
    try {
      const savedJobs = localStorage.getItem('hiresphere_jobs');
      if (savedJobs) return JSON.parse(savedJobs);
    } catch (e) {
      console.error('Error reading jobs from localStorage', e);
    }
    return INITIAL_JOBS;
  });

  // Job Applications State
  const [applications, setApplications] = useState<JobApplication[]>(() => {
    try {
      const savedApps = localStorage.getItem('hiresphere_applications');
      if (savedApps) return JSON.parse(savedApps);
    } catch (e) {
      console.error('Error reading applications from localStorage', e);
    }
    return INITIAL_APPLICATIONS;
  });

  // Active Parsed Resume State
  const [activeResume, setActiveResume] = useState<ParsedResume>(SAMPLE_RESUMES.mohana);

  // Apply Modal state
  const [selectedJobForApply, setSelectedJobForApply] = useState<Job | null>(null);

  // Post-login profile details verification and edit modal state
  const [showPostLoginProfilePrompt, setShowPostLoginProfilePrompt] = useState<boolean>(false);

  // Persist user on changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('hiresphere_active_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('hiresphere_active_user');
    }
  }, [currentUser]);

  // Persist jobs on changes
  useEffect(() => {
    localStorage.setItem('hiresphere_jobs', JSON.stringify(jobs));
  }, [jobs]);

  // Persist applications on changes
  useEffect(() => {
    localStorage.setItem('hiresphere_applications', JSON.stringify(applications));
  }, [applications]);

  // Handle Login or Signup Complete: save user and prompt them for profile details review/editing
  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    setRegisteredUsers(prev => ({
      ...prev,
      [user.email.toLowerCase()]: user
    }));
    try {
      const stored = localStorage.getItem('hiresphere_registered_users');
      const parsed = stored ? JSON.parse(stored) : {};
      parsed[user.email.toLowerCase()] = user;
      localStorage.setItem('hiresphere_registered_users', JSON.stringify(parsed));
    } catch (e) {
      console.warn('Error saving registered user to localStorage', e);
    }
    setShowAuthModal(false);
    // Immediately ask user for profile details where they can review & edit
    setShowPostLoginProfilePrompt(true);
  };

  // Handle Profile Details Save (both post-login and inside the Profile tab)
  const handleSaveProfileDetails = (updatedUser: UserProfile, targetTab?: 'profile' | 'jobs' | 'recruiter') => {
    setCurrentUser(updatedUser);
    setRegisteredUsers(prev => ({
      ...prev,
      [updatedUser.email.toLowerCase()]: updatedUser
    }));
    try {
      localStorage.setItem('hiresphere_active_user', JSON.stringify(updatedUser));
      const stored = localStorage.getItem('hiresphere_registered_users');
      const parsed = stored ? JSON.parse(stored) : {};
      parsed[updatedUser.email.toLowerCase()] = updatedUser;
      localStorage.setItem('hiresphere_registered_users', JSON.stringify(parsed));
    } catch (e) {
      console.warn('Error saving updated user to localStorage', e);
    }
    setShowPostLoginProfilePrompt(false);
    if (targetTab) {
      setActiveTab(targetTab);
    } else if (updatedUser.role === 'recruiter') {
      setActiveTab('recruiter');
    } else {
      setActiveTab('profile');
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setCurrentUser(null);
    setShowPostLoginProfilePrompt(false);
    setShowAuthModal(true);
  };

  // Handle Role Toggle (Switching perspective between Job Seeker and Recruiter)
  const handleToggleRole = () => {
    if (!currentUser) return;
    const newRole = currentUser.role === 'recruiter' ? 'jobseeker' : 'recruiter';
    const updatedUser: UserProfile = {
      ...currentUser,
      role: newRole,
      companyName: newRole === 'recruiter' ? (currentUser.companyName || 'Nexus Cloud Technologies') : undefined
    };
    setCurrentUser(updatedUser);
    if (newRole === 'recruiter') {
      setActiveTab('recruiter');
    } else {
      setActiveTab('jobs');
    }
  };

  // Handle Job Application Submission with formalities
  const handleApplyToJob = (newApplication: JobApplication) => {
    setApplications(prev => [newApplication, ...prev]);
    // Increment applicant count for job
    setJobs(prev => prev.map(j => {
      if (j.id === newApplication.jobId) {
        return { ...j, applicantsCount: j.applicantsCount + 1 };
      }
      return j;
    }));
  };

  // Handle Post New Job from Recruiter Hub
  const handlePostJob = (newJob: Job) => {
    setJobs(prev => [newJob, ...prev]);
  };

  // Handle Recruiter Updating Application Status (Shortlist, Interview, Offer, Reject)
  const handleUpdateApplicationStatus = (appId: string, newStatus: JobApplication['status']) => {
    setApplications(prev => prev.map(app => {
      if (app.id === appId) {
        return { ...app, status: newStatus };
      }
      return app;
    }));
  };

  // Handle saving parsed resume back into User Profile
  const handleSyncResumeToProfile = (resume: ParsedResume) => {
    setActiveResume(resume);
    if (currentUser) {
      const updatedProfile: UserProfile = {
        ...currentUser,
        fullName: resume.fullName,
        email: resume.email,
        phone: resume.phone,
        location: resume.location,
        summary: resume.summary,
        skills: Array.from(new Set([...resume.skills.technical, ...resume.skills.frameworksAndTools])),
        education: resume.education.length > 0 ? resume.education : currentUser.education,
        workHistory: resume.experience.map(exp => ({
          role: exp.title,
          company: exp.company,
          duration: `${exp.startDate} - ${exp.endDate}`,
          description: exp.highlights.join('. ')
        })),
        certifications: resume.certifications
      };
      setCurrentUser(updatedProfile);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900 selection:bg-blue-200">
      
      {/* Universal Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: any) => {
          if (tab === 'builder') setActiveTab('resume-builder');
          else if (tab === 'parser') setActiveTab('resume-parser');
          else setActiveTab(tab);
        }}
        currentUser={currentUser}
        onOpenAuth={() => setShowAuthModal(true)}
        onLogout={handleLogout}
        onToggleRole={handleToggleRole}
        appliedCount={currentUser ? applications.filter(a => a.candidateEmail === currentUser.email).length : 0}
        activeResume={activeResume}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1">
        {/* 1. Job Search & Application View */}
        {activeTab === 'jobs' && (
          <JobSearch
            jobs={jobs}
            currentUser={currentUser || SAMPLE_PROFILES[0]}
            activeResume={activeResume}
            onApply={handleApplyToJob}
            appliedJobIds={new Set(currentUser ? applications.filter(a => a.candidateEmail === currentUser.email).map(a => a.jobId) : [])}
          />
        )}

        {/* 2. Recruiter Hub & Candidate Perspective View */}
        {activeTab === 'recruiter' && (
          <RecruiterPortal
            jobs={jobs}
            applications={applications}
            registeredCandidates={SAMPLE_PROFILES}
            currentRecruiter={
              currentUser?.role === 'recruiter' 
                ? currentUser 
                : {
                    id: 'rec-sample',
                    fullName: currentUser?.fullName || 'Vikramaditya Rao',
                    email: currentUser?.email || 'vikram@nexuscloud.io',
                    phone: '+91 98450 11223',
                    location: 'Bengaluru, India',
                    role: 'recruiter',
                    companyName: 'Nexus Cloud Technologies',
                    title: 'Talent Acquisition & Technical Hiring Lead',
                    experienceYears: 7,
                    experienceLevel: 'Senior',
                    skills: ['Full Stack', 'Cloud Architecture', 'System Design'],
                    summary: 'Head of Engineering Talent at Nexus Cloud Technologies.',
                    education: [{ degree: 'M.Tech Software Systems', institution: 'BITS Pilani', year: '2016' }],
                    workHistory: []
                  }
            }
            onPostJob={handlePostJob}
            onUpdateApplicationStatus={handleUpdateApplicationStatus}
          />
        )}

        {/* 3. Resume Builder View */}
        {(activeTab === 'resume-builder' || (activeTab as any) === 'builder') && (
          <ResumeBuilder
            initialResume={activeResume}
            currentUser={currentUser || SAMPLE_PROFILES[0]}
            onSaveToProfile={handleSyncResumeToProfile}
            onNavigateToJobs={() => setActiveTab('jobs')}
          />
        )}

        {/* 4. Resume Parser View */}
        {(activeTab === 'resume-parser' || (activeTab as any) === 'parser') && (
          <ResumeParser
            currentUser={currentUser || SAMPLE_PROFILES[0]}
            activeResume={activeResume}
            onUpdateResume={setActiveResume}
            onSyncProfile={handleSyncResumeToProfile}
            onOpenInBuilder={() => setActiveTab('resume-builder')}
            onNavigateToJobs={() => setActiveTab('jobs')}
          />
        )}

        {/* 5. User Profile View */}
        {activeTab === 'profile' && (
          <ProfileView
            user={currentUser || SAMPLE_PROFILES[0]}
            applications={applications}
            activeResume={activeResume}
            onUpdateUser={(updated) => handleSaveProfileDetails(updated, 'profile')}
            onSwitchToRecruiter={handleToggleRole}
          />
        )}
      </main>

      {/* Formalities Application Modal */}
      {selectedJobForApply && currentUser && (
        <ApplyModal
          job={selectedJobForApply}
          currentUser={currentUser}
          activeResume={activeResume}
          onClose={() => setSelectedJobForApply(null)}
          onSubmit={handleApplyToJob}
        />
      )}

      {/* Post-Login Profile Details Review & Edit Prompt */}
      {showPostLoginProfilePrompt && currentUser && (
        <ProfileEditorModal
          isOpen={showPostLoginProfilePrompt}
          user={currentUser}
          isPostLogin={true}
          onClose={() => {
            setShowPostLoginProfilePrompt(false);
            if (currentUser.role === 'recruiter') {
              setActiveTab('recruiter');
            } else {
              setActiveTab('jobs');
            }
          }}
          onSave={handleSaveProfileDetails}
        />
      )}

      {/* Authentication & First-Time Signin / Login Modal */}
      {showAuthModal && (
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onAuthSuccess={handleAuthSuccess}
          registeredUsers={registeredUsers}
        />
      )}

      {/* Corporate Footer */}
      <footer className="bg-slate-900 text-slate-400 py-6 text-xs border-t border-slate-800 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white tracking-wide">HireSphere</span>
            <span>•</span>
            <span>An Integrated Job Portal with Resume Parsing</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500 text-[11px]">
            <span>ATS-Compliant Parsing Engine</span>
            <span>•</span>
            <span>Skills Compatibility Matcher</span>
            <span>•</span>
            <a 
              href="/hiresphere-project.zip" 
              download="hiresphere-project.zip"
              className="text-blue-400 hover:text-blue-300 underline font-semibold"
            >
              Download Full Project (.ZIP)
            </a>
          </div>
        </div>
      </footer>

    </div>
  );
}
