export type UserRole = 'jobseeker' | 'recruiter' | 'candidate';

export interface EducationItem {
  degree: string;
  institution: string;
  year: string;
  gpa?: string;
}

export interface WorkHistoryItem {
  role: string;
  company: string;
  duration: string;
  description: string;
}

export interface UserProfile {
  id: string;
  email: string;
  password?: string;
  role: UserRole;
  fullName: string;
  phone: string;
  location: string;
  title: string;
  summary: string;
  experienceYears: number;
  experienceLevel: 'Entry Level' | 'Mid Level' | 'Senior' | 'Lead' | 'Executive';
  skills: string[];
  interests: string[];
  education: EducationItem[];
  workHistory: WorkHistoryItem[];
  certifications: string[];
  portfolioLinks: {
    github?: string;
    linkedin?: string;
    website?: string;
  };
  expectedSalary?: string;
  companyName?: string; // For recruiter
  companyRole?: string; // For recruiter
  companyWebsite?: string;
  createdAt: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'Full-Time' | 'Part-Time' | 'Contract' | 'Remote' | 'Hybrid';
  experienceRequired: string;
  minExperienceYears: number;
  salary: string;
  skills: string[];
  category: string;
  description: string;
  responsibilities: string[];
  requirements: string[];
  postedDate: string;
  recruiterId: string;
  recruiterEmail: string;
  applicantsCount: number;
  isFeatured?: boolean;
}

export interface ParsedResume {
  fullName: string;
  role?: string;
  email: string;
  phone: string;
  location: string;
  links: {
    linkedin?: string;
    github?: string;
    portfolio?: string;
  };
  summary: string;
  skills: {
    technical: string[];
    frameworksAndTools: string[];
    softSkills: string[];
  };
  experience: Array<{
    title: string;
    company: string;
    location?: string;
    startDate: string;
    endDate: string;
    highlights: string[];
  }>;
  education: EducationItem[];
  projects: Array<{
    name: string;
    techStack: string[];
    description: string;
    link?: string;
  }>;
  certifications: string[];
  atsScore: number;
  atsFeedback: string[];
  parsedAt: string;
}

export interface JobApplication {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  candidatePhone: string;
  candidateTitle: string;
  candidateLocation: string;
  matchScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  appliedDate: string;
  status: 'Applied' | 'Under Review' | 'Shortlisted' | 'Interview Scheduled' | 'Offered' | 'Rejected';
  coverNote: string;
  resumeData?: ParsedResume;
}

export interface CandidateEvaluation {
  isWorthy: boolean;
  score: number;
  verdict: 'Strong Fit' | 'Worthy Candidate' | 'Moderate Fit' | 'High Gap';
  matchedSkills: string[];
  missingSkills: string[];
  experienceMatch: boolean;
  reasons: string[];
}

export interface ResumeAuditItem {
  id: string;
  type: 'critical' | 'warning' | 'success';
  category: 'Contact Info' | 'Content Density' | 'Metrics' | 'Action Verbs' | 'Formatting' | 'ATS Compliance';
  title: string;
  message: string;
  recommendation: string;
}

export interface PropathResumeFields {
  template: 'modern' | 'minimal' | 'executive' | 'tech_ats';
  fullName: string;
  role: string;
  email: string;
  phone: string;
  location: string;
  links: string;
  summary: string;
  education: string;
  projects: string;
  experience: string;
  skills: string;
  certs: string;
}

