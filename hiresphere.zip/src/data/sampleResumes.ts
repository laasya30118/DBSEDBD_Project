import { ParsedResume, UserProfile, JobApplication } from '../types';

export const SAMPLE_RESUMES: Record<string, ParsedResume> = {
  mohana: {
    fullName: 'M. Mohana Asmitha',
    email: 'mohanaasmitha@klh.edu.in',
    phone: '+91 98765 43210',
    location: 'Hyderabad, Telangana, India',
    links: {
      linkedin: 'https://linkedin.com/in/mohana-asmitha',
      github: 'https://github.com/mohana-asmitha',
      portfolio: 'https://mohana-portfolio.dev'
    },
    summary: 'Proactive Full Stack & Database Systems Developer with deep expertise in relational database architecture (PostgreSQL, 3NF normalization, indexing, query optimization) and distributed microservices with React and FastAPI. Passionate about automating recruitment screening via intelligent resume parsing and semantic compatibility scoring.',
    skills: {
      technical: ['PostgreSQL', 'SQL Optimization', 'Python', 'TypeScript', 'React', 'FastAPI', 'Data Structures', 'REST APIs'],
      frameworksAndTools: ['Docker', 'Git', 'Tailwind CSS', 'Redis', 'Node.js', 'MongoDB', 'Postman', 'VS Code'],
      softSkills: ['Problem Solving', 'System Architecture', 'Agile Collaboration', 'Technical Documentation']
    },
    experience: [
      {
        title: 'Full Stack & Database Engineering Intern',
        company: 'CloudSphere Solutions',
        location: 'Hyderabad, India',
        startDate: 'June 2025',
        endDate: 'Present',
        highlights: [
          'Designed normalized relational schemas in PostgreSQL with foreign keys and compound indexes, cutting query latency by 42%',
          'Built responsive web interfaces in React.js and styled with Tailwind CSS, supporting 10,000+ monthly active candidate sessions',
          'Engineered asynchronous RESTful endpoints with FastAPI and Pydantic validation for high-throughput payload handling'
        ]
      },
      {
        title: 'Backend Systems Research Fellow',
        company: 'Distributed Computing Lab (KLH)',
        location: 'Hyderabad, India',
        startDate: 'Aug 2024',
        endDate: 'May 2025',
        highlights: [
          'Engineered automated resume parsing algorithms extracting skills, education, and experience entities into structured JSON/relational tables',
          'Implemented compatibility scoring logic matching candidate skill vectors against job vacancy criteria'
        ]
      }
    ],
    education: [
      {
        degree: 'B.Tech in Computer Science & Engineering',
        institution: 'Koneru Lakshmaiah Education Foundation (KL Deemed to be University)',
        year: '2023 - 2027',
        gpa: '9.4 / 10.0'
      }
    ],
    projects: [
      {
        name: 'HireSphere: Integrated Job Portal & Resume Parser',
        techStack: ['React', 'TypeScript', 'PostgreSQL', 'Tailwind CSS', 'FastAPI', 'Redis'],
        description: 'Automated candidate-recruiter portal featuring automated resume parsing, ATS health breakdown, and multidimensional candidate compatibility scoring.',
        link: 'https://github.com/mohana-asmitha/hiresphere-portal'
      },
      {
        name: 'Distributed Microservices Order Engine',
        techStack: ['Python', 'Docker', 'MongoDB', 'Redis', 'JWT'],
        description: 'Scalable polyglot persistence architecture handling order dispatching, token authentication, and cache invalidation.',
        link: 'https://github.com/mohana-asmitha/distributed-orders'
      }
    ],
    certifications: [
      'PostgreSQL Database Administration & Performance Tuning',
      'AWS Certified Cloud Practitioner (Foundational)',
      'Meta Certified Front-End Developer'
    ],
    atsScore: 94,
    atsFeedback: [
      'Excellent action-verb density in experience highlights (Designed, Engineered, Built).',
      'Strong metric quantification with demonstrable results (42% latency reduction, 10k+ sessions).',
      'High keyword alignment with Software Engineering, PostgreSQL, and Full Stack requirements.',
      'Clear, ATS-compliant sequential structure with standard headings.'
    ],
    parsedAt: '2026-09-11 08:00'
  },
  chen: {
    fullName: 'Alex Chen',
    email: 'alex.chen@technova.io',
    phone: '+1 (555) 482-9901',
    location: 'San Francisco, CA (Open to Remote)',
    links: {
      linkedin: 'https://linkedin.com/in/alexchen-ai',
      github: 'https://github.com/alexchen-ai'
    },
    summary: 'Machine Learning & NLP Specialist with 4 years of hands-on production experience deploying transformer models, vector retrieval pipelines (RAG), and generative text agents. Expert in PyTorch, Python, and scalable model serving.',
    skills: {
      technical: ['Python', 'PyTorch', 'TensorFlow', 'NLP', 'FastAPI', 'Vector Databases', 'Transformers', 'LangChain'],
      frameworksAndTools: ['Docker', 'AWS SageMaker', 'HuggingFace', 'Qdrant', 'Kubernetes', 'MLflow'],
      softSkills: ['Research & Innovation', 'Cross-functional Communication', 'Analytical Rigor']
    },
    experience: [
      {
        title: 'Machine Learning Engineer',
        company: 'NeuroScale AI',
        location: 'San Francisco, CA',
        startDate: 'Jan 2024',
        endDate: 'Present',
        highlights: [
          'Trained and deployed fine-tuned domain LLMs and embeddings pipelines with 35% improvement in semantic search precision',
          'Architected RAG systems using Qdrant vector database and hybrid dense-sparse retrieval',
          'Reduced model inference latency from 240ms to 65ms via ONNX runtime optimizations'
        ]
      },
      {
        title: 'NLP Data Scientist',
        company: 'TextCognition Labs',
        location: 'Seattle, WA',
        startDate: 'July 2022',
        endDate: 'Dec 2023',
        highlights: [
          'Built named entity recognition (NER) models for automated document parsing and contract metadata extraction',
          'Collaborated with product teams to roll out automated categorization for 2M+ monthly articles'
        ]
      }
    ],
    education: [
      {
        degree: 'M.S. in Computer Science (Artificial Intelligence)',
        institution: 'University of Washington',
        year: '2020 - 2022',
        gpa: '3.9 / 4.0'
      }
    ],
    projects: [
      {
        name: 'AutoResume Matcher Vector Engine',
        techStack: ['Python', 'FastAPI', 'PyTorch', 'Qdrant', 'Docker'],
        description: 'Semantic candidate-job matching engine utilizing dense vector embeddings and cosine similarity scoring.'
      }
    ],
    certifications: [
      'DeepLearning.AI Natural Language Processing Specialization',
      'AWS Certified Machine Learning - Specialty'
    ],
    atsScore: 91,
    atsFeedback: [
      'High relevance for AI/ML roles with heavy focus on PyTorch, Transformers, and Vector DBs.',
      'Quantifiable impact in each bullet point.',
      'ATS readability is optimal.'
    ],
    parsedAt: '2026-09-10 14:30'
  },
  laasya: {
    fullName: 'G. Laasya',
    email: 'g.laasya@klh.edu.in',
    phone: '+91 91234 56780',
    location: 'Vijayawada / Hyderabad, India',
    links: {
      linkedin: 'https://linkedin.com/in/g-laasya',
      github: 'https://github.com/g-laasya'
    },
    summary: 'Cloud and DevOps Engineer with practical experience designing Docker containers, CI/CD automated release pipelines, and monitoring setups with Prometheus and Grafana. Skilled in AWS cloud architecture, Linux, and Kubernetes orchestration.',
    skills: {
      technical: ['AWS', 'Kubernetes', 'Docker', 'Linux', 'Terraform', 'CI/CD', 'GitHub Actions', 'Python'],
      frameworksAndTools: ['Prometheus', 'Grafana', 'Git', 'Bash', 'PostgreSQL', 'Ansible'],
      softSkills: ['Team Leadership', 'Incident Resolution', 'Attention to Detail']
    },
    experience: [
      {
        title: 'DevOps & Cloud Automation Intern',
        company: 'InfraScale Systems',
        location: 'Hyderabad, India',
        startDate: 'Jan 2025',
        endDate: 'Present',
        highlights: [
          'Provisioned multi-environment VPCs and EC2/EKS clusters on AWS using Terraform declarative manifests',
          'Configured GitHub Actions workflows achieving automated testing and container deployment in under 5 minutes',
          'Established Prometheus alert rules and Grafana dashboards for proactive memory and CPU spike detection'
        ]
      }
    ],
    education: [
      {
        degree: 'B.Tech in Computer Science & Engineering',
        institution: 'Koneru Lakshmaiah Education Foundation',
        year: '2023 - 2027',
        gpa: '9.2 / 10.0'
      }
    ],
    projects: [
      {
        name: 'Containerized Polyglot Microservices Pipeline',
        techStack: ['Docker', 'Kubernetes', 'AWS', 'Grafana', 'Prometheus'],
        description: 'End-to-end multi-service deployment with ingress controller, TLS termination, and health check monitoring.'
      }
    ],
    certifications: [
      'AWS Certified Solutions Architect Associate',
      'Kubernetes Hands-On (CKA Coursework)'
    ],
    atsScore: 89,
    atsFeedback: [
      'Great infrastructure keywords (Kubernetes, Terraform, Prometheus).',
      'Solid timeline formatting and clean educational background.'
    ],
    parsedAt: '2026-09-09 11:15'
  }
};

export const INITIAL_CANDIDATE_PROFILE: UserProfile = {
  id: 'user-candidate-1',
  email: 'mohanaasmitha@klh.edu.in',
  role: 'jobseeker',
  fullName: 'M. Mohana Asmitha',
  phone: '+91 98765 43210',
  location: 'Hyderabad, Telangana, India',
  title: 'Full Stack & Database Systems Developer',
  summary: 'Passionate computer science engineer specializing in scalable relational database design (PostgreSQL), distributed REST APIs (FastAPI/Node.js), and dynamic user interfaces (React/TypeScript). Experienced in building automated resume parsing and intelligent candidate matching systems.',
  experienceYears: 2,
  experienceLevel: 'Mid Level',
  skills: ['React', 'TypeScript', 'PostgreSQL', 'Python', 'FastAPI', 'Docker', 'REST APIs', 'SQL Optimization', 'Tailwind CSS', 'Node.js'],
  interests: ['Full Stack Development', 'Database Engineering', 'Distributed Backend', 'AI Matching Algorithms', 'Cloud Architecture'],
  education: [
    {
      degree: 'B.Tech in Computer Science & Engineering',
      institution: 'Koneru Lakshmaiah Education Foundation (KL University)',
      year: '2023 - 2027',
      gpa: '9.4 / 10.0'
    }
  ],
  workHistory: [
    {
      role: 'Full Stack & Database Engineering Intern',
      company: 'CloudSphere Solutions',
      duration: 'June 2025 - Present',
      description: 'Architected PostgreSQL schemas with 3NF normalization, optimized query execution plans, and built responsive React interfaces for high-throughput candidate portals.'
    },
    {
      role: 'Backend Systems Researcher',
      company: 'Distributed Computing Lab (KLH)',
      duration: 'Aug 2024 - May 2025',
      description: 'Formulated text processing and regex entity extractors for resume parsing and vector similarity compatibility calculations.'
    }
  ],
  certifications: [
    'PostgreSQL Database Systems & Optimization',
    'AWS Certified Cloud Practitioner',
    'Meta Certified Front-End Developer'
  ],
  portfolioLinks: {
    github: 'https://github.com/mohana-asmitha',
    linkedin: 'https://linkedin.com/in/mohana-asmitha',
    website: 'https://mohana-portfolio.dev'
  },
  expectedSalary: '₹18,00,000 / yr',
  createdAt: '2026-09-01'
};

export const INITIAL_RECRUITER_PROFILE: UserProfile = {
  id: 'recruiter-1',
  email: 'recruiter@nexuscloud.io',
  role: 'recruiter',
  fullName: 'Vikramaditya Rao',
  phone: '+91 98450 11223',
  location: 'Bangalore, India',
  title: 'Lead Talent Acquisition Partner & Technical Recruiter',
  summary: 'Technical recruitment specialist at Nexus Cloud Technologies. Focused on hiring exceptional talent across Full Stack, Database Engineering, Distributed Systems, and AI/ML.',
  experienceYears: 8,
  experienceLevel: 'Lead',
  skills: ['Technical Recruiting', 'Talent Sourcing', 'Resume Screening', 'Candidate Evaluation', 'Engineering Hiring'],
  interests: ['Tech Hiring', 'Distributed Architecture', 'Developer Experience'],
  education: [
    {
      degree: 'MBA in Human Resource & Technology Management',
      institution: 'Symbiosis Institute of Business Management',
      year: '2016 - 2018'
    }
  ],
  workHistory: [
    {
      role: 'Lead Talent Acquisition Manager',
      company: 'Nexus Cloud Technologies',
      duration: '2021 - Present',
      description: 'Scaled engineering division from 40 to 250+ developers across India and APAC.'
    }
  ],
  certifications: ['LinkedIn Certified Professional Recruiter', 'SHRM Senior Certified Professional'],
  portfolioLinks: {
    linkedin: 'https://linkedin.com/in/vikram-recruiter'
  },
  companyName: 'Nexus Cloud Technologies',
  companyRole: 'Head of Technical Hiring',
  companyWebsite: 'https://nexuscloud.io',
  createdAt: '2026-08-15'
};

export const INITIAL_APPLICATIONS: JobApplication[] = [
  {
    id: 'app-1',
    jobId: 'job-1',
    jobTitle: 'Senior Full Stack Engineer (React & Node.js)',
    company: 'Nexus Cloud Technologies',
    candidateId: 'user-candidate-1',
    candidateName: 'M. Mohana Asmitha',
    candidateEmail: 'mohanaasmitha@klh.edu.in',
    candidatePhone: '+91 98765 43210',
    candidateTitle: 'Full Stack & Database Systems Developer',
    candidateLocation: 'Hyderabad, Telangana, India',
    matchScore: 92,
    matchedSkills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker'],
    missingSkills: ['AWS'],
    appliedDate: 'Yesterday at 3:45 PM',
    status: 'Shortlisted',
    coverNote: 'I have hands-on experience in building normalized PostgreSQL relational databases, React frontends, and FastAPI microservices. I am passionate about writing clean, reliable code with sub-50ms API queries.',
    resumeData: SAMPLE_RESUMES.mohana
  },
  {
    id: 'app-2',
    jobId: 'job-4',
    jobTitle: 'Backend Systems & Database Engineer',
    company: 'DataSpire Infrastructure',
    candidateId: 'user-candidate-1',
    candidateName: 'M. Mohana Asmitha',
    candidateEmail: 'mohanaasmitha@klh.edu.in',
    candidatePhone: '+91 98765 43210',
    candidateTitle: 'Full Stack & Database Systems Developer',
    candidateLocation: 'Hyderabad, Telangana, India',
    matchScore: 95,
    matchedSkills: ['PostgreSQL', 'Python', 'FastAPI', 'Redis', 'SQL Optimization'],
    missingSkills: ['MongoDB'],
    appliedDate: '2 days ago',
    status: 'Interview Scheduled',
    coverNote: 'My primary academic and internship focus is database engineering, 3NF normalization, and query plan optimization in PostgreSQL. I would love to contribute to DataSpire infrastructure.',
    resumeData: SAMPLE_RESUMES.mohana
  },
  {
    id: 'app-3',
    jobId: 'job-2',
    jobTitle: 'AI & Machine Learning Engineer',
    company: 'Cortex Dynamics AI',
    candidateId: 'user-candidate-2',
    candidateName: 'Alex Chen',
    candidateEmail: 'alex.chen@technova.io',
    candidatePhone: '+1 (555) 482-9901',
    candidateTitle: 'Machine Learning & NLP Specialist',
    candidateLocation: 'San Francisco, CA',
    matchScore: 94,
    matchedSkills: ['Python', 'PyTorch', 'NLP', 'FastAPI', 'Vector Databases', 'LangChain'],
    missingSkills: ['TensorFlow'],
    appliedDate: '3 days ago',
    status: 'Under Review',
    coverNote: 'Extensive background in transformer architectures, vector embeddings matching, and RAG production pipelines.',
    resumeData: SAMPLE_RESUMES.chen
  },
  {
    id: 'app-4',
    jobId: 'job-5',
    jobTitle: 'DevOps & Cloud Platform Engineer',
    company: 'SkyScale Cloud',
    candidateId: 'user-candidate-3',
    candidateName: 'G. Laasya',
    candidateEmail: 'g.laasya@klh.edu.in',
    candidatePhone: '+91 91234 56780',
    candidateTitle: 'DevOps & Cloud Automation Specialist',
    candidateLocation: 'Hyderabad, India',
    matchScore: 88,
    matchedSkills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD', 'GitHub Actions', 'Prometheus'],
    missingSkills: [],
    appliedDate: '4 days ago',
    status: 'Shortlisted',
    coverNote: 'Certified in AWS with practical expertise in Terraform multi-cluster provisioning and GitHub Actions automated pipelines.',
    resumeData: SAMPLE_RESUMES.laasya
  },
  {
    id: 'app-5',
    jobId: 'job-1',
    jobTitle: 'Senior Full Stack Engineer (React & Node.js)',
    company: 'Nexus Cloud Technologies',
    candidateId: 'user-candidate-4',
    candidateName: 'Rohan Verma',
    candidateEmail: 'rohan.v@example.com',
    candidatePhone: '+91 97711 22334',
    candidateTitle: 'Junior Frontend Developer',
    candidateLocation: 'Pune, India',
    matchScore: 48,
    matchedSkills: ['React'],
    missingSkills: ['TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'AWS'],
    appliedDate: '3 days ago',
    status: 'Applied',
    coverNote: 'Keen on moving into full stack development from UI styling.',
    resumeData: {
      fullName: 'Rohan Verma',
      email: 'rohan.v@example.com',
      phone: '+91 97711 22334',
      location: 'Pune, India',
      links: {},
      summary: 'Frontend developer with 1 year experience building basic web views.',
      skills: {
        technical: ['HTML', 'CSS', 'React', 'JavaScript'],
        frameworksAndTools: ['Git', 'VS Code'],
        softSkills: ['Communication']
      },
      experience: [
        {
          title: 'Junior Web Designer',
          company: 'Pixel Web',
          startDate: '2024',
          endDate: 'Present',
          highlights: ['Built landing pages with HTML/CSS']
        }
      ],
      education: [
        {
          degree: 'BCA',
          institution: 'Pune University',
          year: '2024'
        }
      ],
      projects: [],
      certifications: [],
      atsScore: 62,
      atsFeedback: ['Missing backend and database skills for senior role', 'Needs higher metric quantification'],
      parsedAt: '2026-09-08'
    }
  }
];

export const REGISTERED_TALENT_POOL: UserProfile[] = [
  INITIAL_CANDIDATE_PROFILE,
  {
    id: 'user-candidate-2',
    email: 'alex.chen@technova.io',
    role: 'jobseeker',
    fullName: 'Alex Chen',
    phone: '+1 (555) 482-9901',
    location: 'San Francisco, CA (Remote)',
    title: 'Machine Learning & NLP Specialist',
    summary: '4 years of experience deploying LLMs, vector search engines, and computer vision models into high-scale production.',
    experienceYears: 4,
    experienceLevel: 'Senior',
    skills: ['Python', 'PyTorch', 'FastAPI', 'Vector Databases', 'NLP', 'Docker', 'AWS'],
    interests: ['Generative AI', 'Agent Workflows', 'Search & Information Retrieval'],
    education: [
      {
        degree: 'M.S. in Computer Science',
        institution: 'University of Washington',
        year: '2020 - 2022'
      }
    ],
    workHistory: [
      {
        role: 'Machine Learning Engineer',
        company: 'NeuroScale AI',
        duration: '2024 - Present',
        description: 'Trained and deployed fine-tuned domain LLMs and embeddings pipelines.'
      }
    ],
    certifications: ['DeepLearning.AI NLP', 'AWS ML Specialty'],
    portfolioLinks: {
      github: 'https://github.com/alexchen-ai',
      linkedin: 'https://linkedin.com/in/alexchen-ai'
    },
    expectedSalary: '$145,000 / yr',
    createdAt: '2026-08-20'
  },
  {
    id: 'user-candidate-3',
    email: 'g.laasya@klh.edu.in',
    role: 'jobseeker',
    fullName: 'G. Laasya',
    phone: '+91 91234 56780',
    location: 'Hyderabad, India',
    title: 'DevOps & Cloud Automation Specialist',
    summary: 'Specializing in Kubernetes orchestration, AWS cloud infrastructure as code via Terraform, and automated CI/CD pipeline reliability.',
    experienceYears: 2,
    experienceLevel: 'Mid Level',
    skills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD', 'GitHub Actions', 'Prometheus', 'Python'],
    interests: ['Cloud Architecture', 'Infrastructure as Code', 'Site Reliability'],
    education: [
      {
        degree: 'B.Tech in Computer Science',
        institution: 'Koneru Lakshmaiah Education Foundation',
        year: '2023 - 2027'
      }
    ],
    workHistory: [
      {
        role: 'DevOps Automation Intern',
        company: 'InfraScale Systems',
        duration: '2025 - Present',
        description: 'Provisioned multi-environment VPCs and EKS clusters on AWS using Terraform.'
      }
    ],
    certifications: ['AWS Solutions Architect', 'CKA Coursework'],
    portfolioLinks: {
      github: 'https://github.com/g-laasya',
      linkedin: 'https://linkedin.com/in/g-laasya'
    },
    expectedSalary: '₹16,00,000 / yr',
    createdAt: '2026-08-25'
  },
  {
    id: 'user-candidate-4',
    email: 'ch.nohitha@klh.edu.in',
    role: 'jobseeker',
    fullName: 'CH. Nohitha',
    phone: '+91 93456 78901',
    location: 'Hyderabad, India',
    title: 'Distributed Backend & API Engineer',
    summary: 'Focus on distributed service communication, REST/gRPC protocols, MongoDB/PostgreSQL polyglot architectures, and high-performance server logic.',
    experienceYears: 2,
    experienceLevel: 'Mid Level',
    skills: ['Node.js', 'Python', 'PostgreSQL', 'MongoDB', 'Redis', 'Docker', 'REST APIs', 'FastAPI'],
    interests: ['Distributed Systems', 'Database Engineering', 'API Design'],
    education: [
      {
        degree: 'B.Tech in Computer Science',
        institution: 'Koneru Lakshmaiah Education Foundation',
        year: '2023 - 2027'
      }
    ],
    workHistory: [
      {
        role: 'Backend Engineering Fellow',
        company: 'Apex Distributed Labs',
        duration: '2025 - Present',
        description: 'Constructed asynchronous microservices with token authentication and rate limiting.'
      }
    ],
    certifications: ['MongoDB Certified Developer', 'Node.js Application Developer'],
    portfolioLinks: {
      github: 'https://github.com/ch-nohitha',
      linkedin: 'https://linkedin.com/in/ch-nohitha'
    },
    expectedSalary: '₹17,00,000 / yr',
    createdAt: '2026-08-28'
  }
];

export const SAMPLE_PROFILES = REGISTERED_TALENT_POOL;
