import { Job } from '../types';

export const INITIAL_JOBS: Job[] = [
  {
    id: 'job-1',
    title: 'Senior Full Stack Engineer (React & Node.js)',
    company: 'Nexus Cloud Technologies',
    location: 'Bangalore, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '4 - 7 years',
    minExperienceYears: 4,
    salary: '₹22,00,000 - ₹34,00,000 / yr',
    skills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Docker', 'AWS'],
    category: 'Software Engineering',
    description: 'We are looking for a Senior Full Stack Engineer to build high-scale distributed SaaS applications with cutting-edge microservices architecture.',
    responsibilities: [
      'Architect, develop, and deploy scalable front-end and backend services',
      'Optimize database queries and REST/GraphQL APIs for sub-50ms latency',
      'Collaborate with product designers and security auditors',
      'Mentor junior engineers and lead architectural code reviews'
    ],
    requirements: [
      'Bachelor’s degree in Computer Science or equivalent practical experience',
      '4+ years hands-on experience in modern React, TypeScript, and Node.js',
      'Strong knowledge of relational databases (PostgreSQL/MySQL) and caching with Redis',
      'Familiarity with containerization (Docker) and CI/CD pipelines'
    ],
    postedDate: '2 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 14,
    isFeatured: true
  },
  {
    id: 'job-2',
    title: 'AI & Machine Learning Engineer',
    company: 'Cortex Dynamics AI',
    location: 'Hyderabad, India (Remote)',
    type: 'Remote',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹20,00,000 - ₹32,00,000 / yr',
    skills: ['Python', 'PyTorch', 'TensorFlow', 'NLP', 'FastAPI', 'Vector Databases', 'LangChain'],
    category: 'AI & Data Science',
    description: 'Join our research & deployment team building generative AI agent workflows, retrieval-augmented generation (RAG), and domain-specific LLM fine-tuning pipelines.',
    responsibilities: [
      'Develop end-to-end NLP pipelines for resume parsing and vector similarity search',
      'Fine-tune open-source models and integrate state-of-the-art LLMs via FastAPI',
      'Evaluate model performance, token latency, and hallucination guardrails',
      'Maintain pgvector/Qdrant embeddings indexes'
    ],
    requirements: [
      'Strong programming proficiency in Python and deep learning frameworks (PyTorch or TensorFlow)',
      'Proven experience building RAG workflows and embeddings matching systems',
      'Understanding of transformer architectures, attention mechanisms, and cosine similarity'
    ],
    postedDate: '1 day ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 28,
    isFeatured: true
  },
  {
    id: 'job-3',
    title: 'Frontend Developer (React, Tailwind CSS)',
    company: 'FinPulse Systems',
    location: 'Mumbai, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 4 years',
    minExperienceYears: 2,
    salary: '₹14,00,000 - ₹22,00,000 / yr',
    skills: ['React', 'JavaScript', 'Tailwind CSS', 'Next.js', 'Redux', 'Responsive Design'],
    category: 'Frontend Development',
    description: 'Seeking an aesthetic and performance-obsessed Frontend Developer to craft interactive financial analytics dashboards and mobile-responsive trading tools.',
    responsibilities: [
      'Develop responsive, accessible, and fluid UI components using React and Tailwind CSS',
      'Manage client-side state with Redux Toolkit and React Query',
      'Ensure high lighthouse scores, cross-browser compatibility, and fast rendering speeds'
    ],
    requirements: [
      '2+ years of professional React experience',
      'Mastery over semantic HTML5, CSS3, Flexbox/Grid, and Tailwind CSS',
      'Good eye for micro-interactions, motion transitions, and user experience'
    ],
    postedDate: '3 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 19
  },
  {
    id: 'job-4',
    title: 'Backend Systems & Database Engineer',
    company: 'DataSpire Infrastructure',
    location: 'Hyderabad, India (Onsite)',
    type: 'Full-Time',
    experienceRequired: '3 - 6 years',
    minExperienceYears: 3,
    salary: '₹18,00,000 - ₹28,00,000 / yr',
    skills: ['PostgreSQL', 'Python', 'FastAPI', 'Redis', 'SQL Optimization', 'MongoDB'],
    category: 'Backend & Database',
    description: 'Design robust distributed database schemas, execute high-throughput transactions, and manage distributed service communication over REST and gRPC.',
    responsibilities: [
      'Design relational schemas with 3NF normalization, foreign keys, and indexes in PostgreSQL',
      'Optimize query execution plans and database sharding',
      'Construct high-speed asynchronous RESTful APIs using Python FastAPI'
    ],
    requirements: [
      'Expertise in PostgreSQL, indexing strategies, ACID compliance, and SQL tuning',
      'Experience with Python FastAPI or Go microservices',
      'Strong grasp of Redis caching layers and NoSQL documents (MongoDB)'
    ],
    postedDate: 'Just now',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 9,
    isFeatured: true
  },
  {
    id: 'job-5',
    title: 'DevOps & Cloud Platform Engineer',
    company: 'SkyScale Cloud',
    location: 'Bengaluru / Pune, India (Remote)',
    type: 'Remote',
    experienceRequired: '3 - 7 years',
    minExperienceYears: 3,
    salary: '₹20,00,000 - ₹35,00,000 / yr',
    skills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD', 'GitHub Actions', 'Prometheus'],
    category: 'DevOps & Cloud',
    description: 'Scale our multi-region Kubernetes clusters, write Infrastructure as Code (IaC), and automate CI/CD release pipelines with zero downtime.',
    responsibilities: [
      'Provision and maintain cloud infrastructure on AWS using Terraform',
      'Manage container orchestrations with Kubernetes and Helm',
      'Implement observability with Prometheus, Grafana, and OpenTelemetry'
    ],
    requirements: [
      'Hands-on experience with Docker, K8s, and cloud architecture (AWS/GCP)',
      'Experience in automated pipelines (GitHub Actions, GitLab CI)',
      'Understanding of network security, VPCs, and IAM roles'
    ],
    postedDate: '4 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 22
  },
  {
    id: 'job-6',
    title: 'Associate Software Engineer (Java / Spring Boot)',
    company: 'CogniSys Global',
    location: 'Chennai, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '0 - 2 years',
    minExperienceYears: 0,
    salary: '₹7,00,000 - ₹12,00,000 / yr',
    skills: ['Java', 'Spring Boot', 'MySQL', 'REST APIs', 'Git', 'Data Structures'],
    category: 'Software Engineering',
    description: 'Exciting early-career opportunity for aspiring engineers to build enterprise web services, handle distributed messaging, and learn production engineering.',
    responsibilities: [
      'Write clean, well-tested Java code for core banking and transaction modules',
      'Implement secure REST APIs with Spring Security and Hibernate',
      'Participate in daily agile standups and code reviews'
    ],
    requirements: [
      'B.Tech / BE in CSE, IT or related branches with strong academic fundamentals',
      'Solid command of Java, Object-Oriented Programming (OOP), and Collections',
      'Knowledge of SQL queries, joins, and basic API development'
    ],
    postedDate: '1 day ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 45
  },
  {
    id: 'job-7',
    title: 'Data Analyst / BI Specialist',
    company: 'MetricFlow Analytics',
    location: 'Gurugram, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '1 - 3 years',
    minExperienceYears: 1,
    salary: '₹9,00,000 - ₹15,00,000 / yr',
    skills: ['SQL', 'Python', 'Power BI', 'Excel', 'Tableau', 'Data Cleaning'],
    category: 'AI & Data Science',
    description: 'Transform raw customer interaction data into actionable executive insights, automated dashboards, and predictive trend reports.',
    responsibilities: [
      'Extract and transform data from relational and warehouse databases using complex SQL',
      'Build executive dashboards in Power BI / Tableau',
      'Perform exploratory data analysis using Python (Pandas, NumPy, Seaborn)'
    ],
    requirements: [
      'Proficiency in SQL querying, window functions, and aggregations',
      '1+ years experience in dashboard creation and visualization',
      'Strong problem-solving mindset and business communication skills'
    ],
    postedDate: '5 days ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 31
  },
  {
    id: 'job-8',
    title: 'UI/UX Product Designer',
    company: 'Zenith Studio Labs',
    location: 'Bengaluru, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹12,00,000 - ₹20,00,000 / yr',
    skills: ['Figma', 'User Research', 'Wireframing', 'Prototyping', 'Design Systems', 'UI/UX'],
    category: 'Product & Design',
    description: 'Shape human-centered user experiences for our next-generation web and mobile products. Partner directly with founders, engineers, and product managers.',
    responsibilities: [
      'Conduct user interviews, usability tests, and competitor evaluations',
      'Design high-fidelity wireframes, flows, and interactive prototypes in Figma',
      'Maintain and expand our scalable design system and component libraries'
    ],
    requirements: [
      'Demonstrable portfolio illustrating product design end-to-end case studies',
      'Deep understanding of typography, spacing, accessibility standards, and visual rhythm',
      'Experience collaborating with engineers on front-end handoff'
    ],
    postedDate: '3 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 16
  },
  {
    id: 'job-9',
    title: 'Cybersecurity Analyst & Penetration Tester',
    company: 'Fortress Cyber Guard',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹15,00,000 - ₹26,00,000 / yr',
    skills: ['Network Security', 'Vulnerability Assessment', 'OWASP', 'Linux', 'Python', 'Wireshark'],
    category: 'Security & QA',
    description: 'Protect enterprise infrastructure through proactive vulnerability scans, penetration testing, threat modeling, and incident remediation.',
    responsibilities: [
      'Execute web application security assessments according to OWASP Top 10',
      'Audit cloud IAM roles, firewall policies, and cryptographic controls',
      'Formulate remediation guides and present security reports to leadership'
    ],
    requirements: [
      'Experience in ethical hacking, network analysis, and vulnerability exploitation tools',
      'Certifications such as CEH, CompTIA Security+, or OSCP are a strong plus',
      'Familiarity with secure coding practices and API security'
    ],
    postedDate: '2 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 11
  },
  {
    id: 'job-10',
    title: 'Mobile App Developer (React Native & Flutter)',
    company: 'OmniApp Labs',
    location: 'Noida / Delhi NCR (Remote)',
    type: 'Remote',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹13,00,000 - ₹24,00,000 / yr',
    skills: ['React Native', 'Flutter', 'JavaScript', 'TypeScript', 'iOS', 'Android', 'REST APIs'],
    category: 'Mobile Development',
    description: 'Build fast, native-feeling mobile applications for both iOS and Android platforms with smooth animations and offline data synchronization.',
    responsibilities: [
      'Develop cross-platform mobile features using React Native or Flutter',
      'Integrate push notifications, in-app purchases, and device sensors',
      'Publish and manage builds on Apple App Store and Google Play Store'
    ],
    requirements: [
      '2+ years of production experience in React Native or Flutter',
      'Solid grasp of mobile state management, lifecycle, and memory management',
      'Portfolio of live apps available on app stores'
    ],
    postedDate: '6 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 23
  },
  {
    id: 'job-11',
    title: 'QA Automation Engineer (Selenium, Cypress)',
    company: 'QualiVibe Systems',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 4 years',
    minExperienceYears: 2,
    salary: '₹10,00,000 - ₹18,00,000 / yr',
    skills: ['Automation Testing', 'Selenium', 'Cypress', 'Java', 'Python', 'Postman', 'CI/CD'],
    category: 'Security & QA',
    description: 'Ensure our mission-critical SaaS platforms deliver flawless quality through automated end-to-end regression suites and load testing.',
    responsibilities: [
      'Build and maintain test automation frameworks using Cypress and Selenium',
      'Automate API testing with Postman and RestAssured',
      'Integrate test pipelines into GitHub Actions for pull-request gating'
    ],
    requirements: [
      'Strong knowledge of test automation frameworks in Java or JavaScript/TypeScript',
      'Experience with functional, non-functional, regression, and API testing',
      'Familiarity with bug tracking in Jira'
    ],
    postedDate: '1 day ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 15
  },
  {
    id: 'job-12',
    title: 'Product Manager (Technical / SaaS)',
    company: 'OrbitSaaS Global',
    location: 'Bengaluru, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '3 - 6 years',
    minExperienceYears: 3,
    salary: '₹22,00,000 - ₹36,00,000 / yr',
    skills: ['Product Strategy', 'Agile / Scrum', 'Roadmapping', 'User Research', 'Data Analysis', 'Jira'],
    category: 'Product & Design',
    description: 'Lead product definition and feature delivery for enterprise recruitment and workforce management platforms.',
    responsibilities: [
      'Define product roadmap, prioritize features, and write comprehensive PRDs',
      'Work closely with engineering, UX designers, and sales leaders',
      'Track north-star metrics, user retention, and feature adoption rates'
    ],
    requirements: [
      '3+ years in B2B or B2C SaaS product management',
      'Strong technical acumen to communicate effectively with software engineers',
      'Customer-first mindset with proven analytical and storytelling skills'
    ],
    postedDate: '3 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 17
  },
  {
    id: 'job-13',
    title: 'Data Engineer (PySpark, SQL, Snowflake)',
    company: 'DataStream Lakehouse',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '3 - 6 years',
    minExperienceYears: 3,
    salary: '₹18,00,000 - ₹30,00,000 / yr',
    skills: ['Python', 'PySpark', 'SQL', 'Snowflake', 'Airflow', 'Kafka', 'ETL Pipelines'],
    category: 'AI & Data Science',
    description: 'Construct resilient batch and streaming ETL pipelines processing millions of events per second into analytical data lakes.',
    responsibilities: [
      'Build scalable data ingestion workflows with Apache Airflow and PySpark',
      'Model dimension and fact schemas in Snowflake / BigQuery',
      'Maintain data governance, SLA monitoring, and data quality tests'
    ],
    requirements: [
      'Proficiency with Python, advanced SQL, and big data engines',
      'Experience with event streaming systems (Kafka / RabbitMQ)',
      'Hands-on experience with cloud data warehouses'
    ],
    postedDate: '5 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 18
  },
  {
    id: 'job-14',
    title: 'Golang Distributed Backend Engineer',
    company: 'HyperScale Networks',
    location: 'Remote / Bengaluru, India',
    type: 'Remote',
    experienceRequired: '3 - 6 years',
    minExperienceYears: 3,
    salary: '₹24,00,000 - ₹38,00,000 / yr',
    skills: ['Go (Golang)', 'Microservices', 'gRPC', 'PostgreSQL', 'Redis', 'Docker', 'Kubernetes'],
    category: 'Backend & Database',
    description: 'Work on ultra-low-latency backend infrastructure powering payment gateways and distributed consensus algorithms.',
    responsibilities: [
      'Implement concurrent services in Go utilizing goroutines and channels',
      'Write gRPC and protobuf definitions for high-speed inter-service communication',
      'Tune memory allocations, garbage collection, and database connection pools'
    ],
    requirements: [
      'Proficiency in Go with deep understanding of concurrency primitives',
      'Solid experience in distributed microservices and database design',
      'Comfortable writing unit and integration tests with benchmarking'
    ],
    postedDate: '4 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 12,
    isFeatured: true
  },
  {
    id: 'job-15',
    title: 'Junior React Frontend Developer',
    company: 'SparkTech Solutions',
    location: 'Chennai, India (Onsite)',
    type: 'Full-Time',
    experienceRequired: '0 - 2 years',
    minExperienceYears: 0,
    salary: '₹5,50,000 - ₹9,00,000 / yr',
    skills: ['React', 'JavaScript', 'HTML5', 'CSS3', 'Git', 'REST APIs'],
    category: 'Frontend Development',
    description: 'A great kick-off role for enthusiastic developers eager to build modern responsive web portals alongside seasoned senior frontend architects.',
    responsibilities: [
      'Build user interfaces from Figma mockups using clean React components',
      'Integrate backend REST endpoints with fetch/axios and display dynamic data',
      'Fix UI bugs, improve accessibility, and write component unit tests'
    ],
    requirements: [
      'Good understanding of JavaScript ES6+, React Hooks, and DOM manipulation',
      'Enthusiastic about web standards, responsive design, and CSS frameworks',
      'Personal projects or internship experience in React.js'
    ],
    postedDate: 'Just now',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 52
  },
  {
    id: 'job-16',
    title: 'Cloud Solutions Architect (AWS / GCP)',
    company: 'Apex Enterprise Consulting',
    location: 'Bengaluru / Hyderabad, India',
    type: 'Hybrid',
    experienceRequired: '7 - 12 years',
    minExperienceYears: 7,
    salary: '₹35,00,000 - ₹55,00,000 / yr',
    skills: ['AWS', 'GCP', 'System Design', 'Enterprise Architecture', 'Security', 'Cost Optimization'],
    category: 'DevOps & Cloud',
    description: 'Advise Fortune 500 clients on enterprise cloud migration, disaster recovery, cost governance, and fault-tolerant cloud native patterns.',
    responsibilities: [
      'Produce technical architecture blueprints for multi-tenant hybrid cloud systems',
      'Direct migration of legacy monoliths to microservices and serverless stacks',
      'Establish security baselines, SOC2 compliance, and encryption standards'
    ],
    requirements: [
      '7+ years experience in software architecture and cloud infrastructure',
      'AWS Certified Solutions Architect Professional or Google Cloud Architect certified',
      'Exceptional stakeholder presentation and strategic roadmap leadership'
    ],
    postedDate: '6 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 7
  },
  {
    id: 'job-17',
    title: 'Computer Vision & Deep Learning Specialist',
    company: 'VisionaryAI Systems',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 6 years',
    minExperienceYears: 2,
    salary: '₹22,00,000 - ₹36,00,000 / yr',
    skills: ['Python', 'OpenCV', 'PyTorch', 'YOLO', 'Computer Vision', 'Deep Learning'],
    category: 'AI & Data Science',
    description: 'Develop edge AI vision models for industrial automation, object detection, facial recognition, and document optical character recognition (OCR).',
    responsibilities: [
      'Train and optimize convolutional and vision transformer models',
      'Implement real-time video stream inferencing pipelines using OpenCV and ONNX',
      'Deploy models onto edge devices and cloud GPU endpoints'
    ],
    requirements: [
      'Master’s or Bachelor’s in AI, CS, or Robotics with practical computer vision experience',
      'Proficiency in PyTorch, OpenCV, model quantization, and image preprocessing'
    ],
    postedDate: '2 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 14
  },
  {
    id: 'job-18',
    title: 'Next.js & Full Stack Engineer',
    company: 'Veloce Digital Media',
    location: 'Remote, India',
    type: 'Remote',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹16,00,000 - ₹26,00,000 / yr',
    skills: ['Next.js', 'React', 'TypeScript', 'Tailwind CSS', 'Prisma', 'PostgreSQL'],
    category: 'Software Engineering',
    description: 'Develop customer-facing digital web experiences with Next.js App Router, Server Components, and seamless database interactions.',
    responsibilities: [
      'Build lightning-fast web applications leveraging SSR, ISR, and Edge middleware',
      'Design clean schema migrations with Prisma ORM and PostgreSQL',
      'Integrate payment processing and analytical tracking'
    ],
    requirements: [
      '2+ years with Next.js and TypeScript',
      'Strong grasp of web performance, caching headers, and SEO best practices'
    ],
    postedDate: '3 days ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 26
  },
  {
    id: 'job-19',
    title: 'Database Administrator (PostgreSQL & MongoDB)',
    company: 'SecureDB Solutions',
    location: 'Pune, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '4 - 8 years',
    minExperienceYears: 4,
    salary: '₹18,00,000 - ₹28,00,000 / yr',
    skills: ['PostgreSQL', 'MongoDB', 'Database Tuning', 'Backup & Recovery', 'Replication', 'Linux'],
    category: 'Backend & Database',
    description: 'Ensure 99.999% availability of mission-critical databases with proactive monitoring, automated backups, and index optimization.',
    responsibilities: [
      'Manage high-availability database clusters, read replicas, and failover mechanisms',
      'Analyze slow query logs, vacuuming, and lock contention in PostgreSQL',
      'Plan database capacity, storage scaling, and disaster recovery drills'
    ],
    requirements: [
      'Proven track record as a Production DBA managing large PostgreSQL fleets',
      'Familiarity with MongoDB replica sets and sharding',
      'Strong Linux shell scripting skills for automation'
    ],
    postedDate: '4 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 8
  },
  {
    id: 'job-20',
    title: 'Site Reliability Engineer (SRE)',
    company: 'Apex Cloud Systems',
    location: 'Bengaluru, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '3 - 6 years',
    minExperienceYears: 3,
    salary: '₹20,00,000 - ₹32,00,000 / yr',
    skills: ['Linux', 'Kubernetes', 'Python', 'Go', 'Prometheus', 'Incident Management'],
    category: 'DevOps & Cloud',
    description: 'Champion system resilience, automate toil, define SLOs/SLIs, and lead blameless post-mortem investigations across our cloud platform.',
    responsibilities: [
      'Define Service Level Objectives (SLOs) and error budgets for tier-1 microservices',
      'Automate incident remediation and self-healing infrastructure using Python and Go',
      'Maintain alerting thresholds to prevent on-call fatigue'
    ],
    requirements: [
      'Deep Linux internals knowledge and troubleshooting skills',
      'Experience operating distributed systems in Kubernetes',
      'Strong coding capability for systems tooling'
    ],
    postedDate: '1 week ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 14
  },
  {
    id: 'job-21',
    title: 'Python Backend Developer (Django / Flask)',
    company: 'InsightEdge Analytics',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '2 - 4 years',
    minExperienceYears: 2,
    salary: '₹12,00,000 - ₹19,00,000 / yr',
    skills: ['Python', 'Django', 'REST APIs', 'PostgreSQL', 'Celery', 'Redis'],
    category: 'Backend & Database',
    description: 'Develop backends for analytics products using Django REST Framework, Celery asynchronous workers, and Redis message queues.',
    responsibilities: [
      'Design RESTful web services and background batch workers',
      'Integrate third-party SaaS APIs and webhook handlers',
      'Write modular, well-documented code with comprehensive test coverage'
    ],
    requirements: [
      'Proficiency in Python and Django / Flask',
      'Experience with Celery task queues and relational databases',
      'Solid understanding of authentication, permissions, and session management'
    ],
    postedDate: '3 days ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 29
  },
  {
    id: 'job-22',
    title: 'Technical Recruiter & Talent Partner',
    company: 'TalentSphere HR Tech',
    location: 'Remote / Bengaluru, India',
    type: 'Remote',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹10,00,000 - ₹18,00,000 / yr',
    skills: ['Technical Sourcing', 'Resume Screening', 'Interviewing', 'Applicant Tracking Systems', 'LinkedIn Recruiter'],
    category: 'HR & Recruiting',
    description: 'Partner directly with engineering leadership to source, evaluate, and hire top-tier software engineers and product managers.',
    responsibilities: [
      'Source high-caliber engineering talent across GitHub, LinkedIn, and developer communities',
      'Conduct initial candidate screenings and evaluate cultural alignment',
      'Guide candidates smoothly through interview stages and offer negotiations'
    ],
    requirements: [
      '2+ years technical recruiting experience for software product teams',
      'Understanding of modern tech stacks (React, Node, Cloud, AI)',
      'Excellent interpersonal communication and relationship-building abilities'
    ],
    postedDate: '5 days ago',
    recruiterId: 'recruiter-1',
    recruiterEmail: 'recruiter@nexuscloud.io',
    applicantsCount: 34
  },
  {
    id: 'job-23',
    title: 'Blockchain & Web3 Smart Contract Engineer',
    company: 'DecentraChain Labs',
    location: 'Bengaluru, India (Remote)',
    type: 'Remote',
    experienceRequired: '2 - 5 years',
    minExperienceYears: 2,
    salary: '₹22,00,000 - ₹40,00,000 / yr',
    skills: ['Solidity', 'Ethereum', 'Web3.js', 'Ethers.js', 'Smart Contracts', 'Security Audits'],
    category: 'Software Engineering',
    description: 'Design and deploy audited Solidity smart contracts, DeFi protocols, and decentralized governance mechanisms.',
    responsibilities: [
      'Write gas-optimized, secure Solidity smart contracts',
      'Conduct static analysis with Slither and Mythril',
      'Connect frontend decentralized apps with MetaMask and Ethers.js'
    ],
    requirements: [
      'Proven experience deploying live contracts on EVM-compatible chains',
      'Rigorous attention to smart contract security vulnerabilities and reentrancy vectors'
    ],
    postedDate: '4 days ago',
    recruiterId: 'recruiter-2',
    recruiterEmail: 'hiring@finpulse.com',
    applicantsCount: 16
  },
  {
    id: 'job-24',
    title: 'Technical Support & Solutions Engineer',
    company: 'ClientCare SaaS',
    location: 'Hyderabad, India (Hybrid)',
    type: 'Full-Time',
    experienceRequired: '1 - 3 years',
    minExperienceYears: 1,
    salary: '₹8,00,000 - ₹14,00,000 / yr',
    skills: ['SQL', 'JavaScript', 'REST APIs', 'Technical Troubleshooting', 'Customer Success'],
    category: 'Software Engineering',
    description: 'Troubleshoot complex enterprise customer integration questions, inspect API payload logs, and resolve technical tickets.',
    responsibilities: [
      'Diagnose customer issues by reading API logs and database queries',
      'Write integration guides, code snippets, and technical knowledge base articles',
      'Collaborate with core development engineers on bug triage'
    ],
    requirements: [
      'Strong problem analysis skills and understanding of HTTP status codes / REST APIs',
      'Basic programming ability in JavaScript or Python',
      'Patient and articulate customer communication'
    ],
    postedDate: '1 week ago',
    recruiterId: 'recruiter-3',
    recruiterEmail: 'careers@cognisys.com',
    applicantsCount: 21
  }
];
